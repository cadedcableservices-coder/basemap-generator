# Fiber Basemap Generator

Automatically generate simple, CAD-ready basemaps for fiber-optic construction
drawings from open GIS data (OpenStreetMap), replacing the manual trace-and-offset
workflow. Roads, road names, state-route numbers, waterways, water bodies, and
building footprints are fetched, classified, offset into roadway edges, and
exported to **DXF + GeoPackage + Shapefiles** with a **QC report** — always with a
human review/correction step.

> This basemap is generated from third-party geographic data to assist drafting.
> It is **not** a survey, utility locate, right-of-way determination, or
> engineering certification. Review all data before construction use.

## Status
- **Phase 1 (command-line):** complete, tested.
- **Phase 2 (web app — map, search, boundary drawing, generate, review, export):** complete, tested.
- **Phase 3 (editing — reclassify, include/exclude, width, delete, geometry edits, single-edge offset):** implemented.
- **Phase 4 (auth, shared PostGIS, audit trail):** not started by design.
- **39 automated tests pass, fully offline.**

## Quick start — web app
```bash
# Windows: double-click  scripts\Start Basemap Generator.bat
# Any OS:
pip install -r backend/requirements.txt
python run.py            # opens http://127.0.0.1:8000
```
Draw an area on the map, click Generate, review the roads, and Export the CAD ZIP.
Tick "Use bundled sample data" to try it offline. Needs internet for live OSM
data + map tiles.

## Quick start — CLI (offline demo)
```bash
python -m backend.app.cli --project "PineCreek_Demo" \
  --bbox -77.276 41.195 -77.264 41.207 \
  --overpass-json sample_data/pa_rural_pine_creek.overpass.json --out output
```

## Live OpenStreetMap fetch
Drop `--overpass-json` to fetch from Overpass for a real area (needs network):
```bash
python -m backend.app.cli --project "MyArea" --bbox -77.276 41.195 -77.264 41.207
```

## Tests
```bash
pytest            # 31 offline tests (unit + integration)
```

## Docs
`docs/architecture.md` (design, data-flow diagram, spec review),
`installation.md`, `user_guide.md`, `data_sources.md`, `cad_import.md`.

## Configuration (no code changes needed)
- `config/road_classification.yaml` — highway→class rules, state-route patterns
- `config/cad_layers.yaml` — CAD layer names + colors
- `config/default_settings.yaml` — widths, interpretation, water/building toggles, CRS presets, API safety

## Key capabilities & honest limitations
Provides available road/water/building geometry, names, route refs, and
approximate 18/20 ft roadway-edge offsets in a projected CRS. It **cannot**
guarantee true pavement edges, right-of-way, exact widths, bridges, utilities, or
survey/construction-grade accuracy — unknowns are flagged, never invented.
