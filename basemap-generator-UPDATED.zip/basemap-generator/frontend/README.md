# Frontend

`index.html` is the entire web UI — a single self-contained page (Leaflet map +
Leaflet-Geoman drawing tools, vanilla JS) served by the FastAPI backend at `/`.
No build step. Libraries load from CDN, so the browser needs internet (which is
required anyway for OpenStreetMap tiles and data).

To run: `python run.py` from the repo root, then open http://127.0.0.1:8000.

A future React + Vite version could replace this file without changing the API.
