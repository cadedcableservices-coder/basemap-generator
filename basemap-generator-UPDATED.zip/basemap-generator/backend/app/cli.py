"""Command-line entry point for the Phase-1 basemap prototype.

Examples
--------
# From the bundled offline PA sample (no internet needed):
python -m backend.app.cli --project "PineCreek_Demo" \
    --bbox -77.276 41.195 -77.264 41.207 \
    --overpass-json sample_data/pa_rural_pine_creek.overpass.json \
    --out output

# Live OpenStreetMap fetch (needs network access to Overpass):
python -m backend.app.cli --project "MyArea" --bbox -77.276 41.195 -77.264 41.207
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

from .core.logging import get_logger
from . import pipeline

log = get_logger("cli")


def build_overrides(args) -> dict:
    ov: dict = {}
    if args.width_interpretation:
        ov["width_interpretation"] = args.width_interpretation
    if args.crs_epsg:
        ov["crs_mode"] = "epsg"
        ov["crs_epsg"] = args.crs_epsg
    if args.building_mode:
        ov.setdefault("buildings", {})["mode"] = args.building_mode
    return ov


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Fiber basemap generator (Phase 1 CLI)")
    p.add_argument("--project", required=True, help="Project name")
    p.add_argument("--bbox", nargs=4, type=float, metavar=("W", "S", "E", "N"),
                   help="WGS84 bounding box: west south east north")
    p.add_argument("--geojson", help="Path to a boundary GeoJSON (polygon)")
    p.add_argument("--overpass-json", help="Use a saved Overpass response (offline)")
    p.add_argument("--out", default="output", help="Output directory")
    p.add_argument("--width-interpretation", choices=["total_width", "edge_offset"])
    p.add_argument("--crs-epsg", type=int, help="Force a working EPSG code")
    p.add_argument("--building-mode",
                   choices=["footprint", "rotated_rect", "bbox", "none"])
    args = p.parse_args(argv)

    if not args.bbox and not args.geojson:
        p.error("one of --bbox or --geojson is required")

    result = pipeline.run(
        args.project, bbox=tuple(args.bbox) if args.bbox else None,
        geojson_path=args.geojson, overpass_json=args.overpass_json,
        overrides=build_overrides(args), out_dir=args.out)

    c = result
    print("\n===== BASEMAP GENERATION COMPLETE =====")
    print(f"Working CRS   : EPSG:{c.crs_info.epsg} ({c.crs_info.unit_name})")
    print(f"Road edges    : {c.offset_stats.edges_created} "
          f"(failed offsets: {c.offset_stats.failed})")
    print(f"Invalid geoms : {c.validation_stats.invalid_found} "
          f"(repaired: {c.validation_stats.repaired})")
    print(f"Export ZIP    : {c.export_zip}")
    if c.warnings:
        print("Warnings:")
        for w in c.warnings:
            print(f"  - {w}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
