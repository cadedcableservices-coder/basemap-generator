"""REST endpoints (spec section 19)."""
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from ..core.logging import get_logger
from ..providers.osm_overpass import OsmOverpassProvider
from ..schemas.models import (GeocodeRequest, CreateProjectRequest, BoundaryRequest,
                              FetchRequest, SettingsRequest, FeatureEdit, AddRoadRequest)
from ..core.config import deep_merge
from .state import STORE

log = get_logger(__name__)
router = APIRouter(prefix="/api")


def _summary(asm):
    o, v = asm.offset_stats, asm.validation_stats
    return {
        "crs_epsg": asm.crs_info.epsg, "crs_unit": asm.crs_info.unit_name,
        "provider": asm.provider_name,
        "boundary_area_sqft": round(asm.boundary_area_sqft, 1),
        "roads": len(asm.fc.of_kind("road_centerline")),
        "road_edges": o.edges_created, "failed_offsets": o.failed,
        "water": len(asm.fc.of_kind("stream", "river", "ditch", "drain", "water_body")),
        "buildings": len([b for b in asm.fc.of_kind("building") if b.get("include", True)]),
        "invalid_geoms": v.invalid_found, "repaired": v.repaired,
        "warnings": asm.warnings,
    }


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/geocode")
def geocode(req: GeocodeRequest):
    prov = OsmOverpassProvider()
    return {"results": prov.search_location(req.query)}


@router.post("/project")
def create_project(req: CreateProjectRequest):
    p = STORE.create(req.name, req.settings)
    return {"project_id": p.project_id, "name": p.name, "settings": p.settings}


@router.get("/project/{pid}")
def get_project(pid: str):
    try:
        p = STORE.get(pid)
    except KeyError:
        raise HTTPException(404, "project not found")
    return {"project_id": p.project_id, "name": p.name, "settings": p.settings,
            "bbox": p.bbox, "has_features": p.assembly is not None,
            "use_sample": p.use_sample}


@router.post("/project/{pid}/boundary")
def set_boundary(pid: str, req: BoundaryRequest):
    try:
        p = STORE.get(pid)
    except KeyError:
        raise HTTPException(404, "project not found")
    if not req.bbox and not req.geojson:
        raise HTTPException(400, "provide bbox or geojson")
    p.bbox = req.bbox
    p.boundary_geojson = req.geojson
    return {"ok": True}


@router.put("/project/{pid}/settings")
def update_settings(pid: str, req: SettingsRequest):
    try:
        p = STORE.get(pid)
    except KeyError:
        raise HTTPException(404, "project not found")
    p.settings = deep_merge(p.settings, req.settings)
    # if features already generated, re-assemble so new widths/CRS take effect
    if p.assembly is not None:
        STORE.assemble(p)
    return {"settings": p.settings}


@router.post("/project/{pid}/fetch-features")
def fetch_features(pid: str, req: FetchRequest):
    try:
        p = STORE.get(pid)
    except KeyError:
        raise HTTPException(404, "project not found")
    if not p.bbox and not p.boundary_geojson:
        raise HTTPException(400, "set a boundary first")
    p.use_sample = req.use_sample
    try:
        asm = STORE.assemble(p)
    except Exception as exc:
        log.exception("assemble failed")
        raise HTTPException(502, f"data fetch/processing failed: {exc}")
    return {"summary": _summary(asm), "geojson": STORE.geojson(p)}


@router.get("/project/{pid}/features")
def get_features(pid: str):
    p = STORE.get(pid)
    if p.assembly is None:
        raise HTTPException(400, "no features yet")
    return STORE.geojson(p)


@router.patch("/project/{pid}/features/{fid}")
def edit_feature(pid: str, fid: str, req: FeatureEdit):
    p = STORE.get(pid)
    if p.assembly is None:
        raise HTTPException(400, "no features yet")
    try:
        STORE.edit_feature(p, fid, req.attributes, req.geometry)
    except KeyError:
        raise HTTPException(404, "feature not found")
    return {"ok": True, "geojson": STORE.geojson(p)}


@router.delete("/project/{pid}/features/{fid}")
def delete_feature(pid: str, fid: str):
    p = STORE.get(pid)
    if p.assembly is None:
        raise HTTPException(400, "no features yet")
    STORE.delete_feature(p, fid)
    return {"ok": True, "geojson": STORE.geojson(p)}


@router.post("/project/{pid}/add-road")
def add_road(pid: str, req: AddRoadRequest):
    p = STORE.get(pid)
    if p.assembly is None:
        raise HTTPException(400, "generate features first")
    fid = STORE.add_road(p, req.geometry, req.attributes)
    return {"ok": True, "feature_id": fid, "geojson": STORE.geojson(p)}


@router.post("/project/{pid}/export")
def export(pid: str):
    p = STORE.get(pid)
    if p.assembly is None:
        raise HTTPException(400, "no features to export")
    zip_path = STORE.export(p)
    eid = next(k for k, v in p.exports.items() if v == zip_path)
    return {"export_id": eid, "download_url": f"/api/project/{pid}/export/{eid}"}


@router.get("/project/{pid}/export/{eid}")
def download_export(pid: str, eid: str):
    p = STORE.get(pid)
    if eid not in p.exports:
        raise HTTPException(404, "export not found")
    zp = p.exports[eid]
    return FileResponse(str(zp), media_type="application/zip",
                        filename=zp.name)
