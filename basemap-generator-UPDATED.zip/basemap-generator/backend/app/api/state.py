"""In-memory project store for the web app (Phase 2).

A project holds its settings, boundary, and the assembled FeatureCollection in
the working CRS. Exports and the settings JSON are written to disk so a project
can be regenerated. Multi-user persistence (PostGIS) is Phase 4.
"""
from __future__ import annotations
import uuid
from dataclasses import dataclass, field
import tempfile
from pathlib import Path
from typing import Any

from pyproj import Transformer
from shapely.geometry import shape
from shapely.ops import transform as shp_transform

from ..core.config import AppConfig, CONFIG_DIR
from ..core.logging import get_logger
from ..models.features import Feature
from .. import pipeline
from ..services import projections as proj

log = get_logger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[3]
SAMPLE_JSON = REPO_ROOT / "sample_data" / "pa_rural_pine_creek.overpass.json"
PROJECTS_DIR = Path(tempfile.gettempdir()) / "basemap_projects"


@dataclass
class Project:
    project_id: str
    name: str
    settings: dict[str, Any] = field(default_factory=dict)   # overrides on defaults
    bbox: list[float] | None = None
    boundary_geojson: dict | None = None
    use_sample: bool = False
    assembly: pipeline.Assembly | None = None
    exports: dict[str, Path] = field(default_factory=dict)

    def cfg(self) -> AppConfig:
        return AppConfig.load(overrides=self.settings)


def _sample_bbox(pad: float = 0.0015):
    """Bounding box (W,S,E,N) covering all geometry in the bundled sample."""
    import json
    doc = json.loads(SAMPLE_JSON.read_text(encoding="utf-8"))
    lons, lats = [], []
    for el in doc.get("elements", []):
        for g in el.get("geometry", []):
            lons.append(g["lon"]); lats.append(g["lat"])
    return (min(lons) - pad, min(lats) - pad, max(lons) + pad, max(lats) + pad)


class ProjectStore:
    def __init__(self):
        self._projects: dict[str, Project] = {}

    def create(self, name: str, settings: dict | None = None) -> Project:
        pid = uuid.uuid4().hex[:12]
        p = Project(project_id=pid, name=name or f"Project_{pid}",
                    settings=settings or {})
        self._projects[pid] = p
        log.info("Created project %s (%s)", pid, p.name)
        return p

    def get(self, pid: str) -> Project:
        if pid not in self._projects:
            raise KeyError(pid)
        return self._projects[pid]

    # ---- pipeline actions -------------------------------------------
    def assemble(self, p: Project) -> pipeline.Assembly:
        cfg = p.cfg()
        if p.use_sample:
            # Offline demo: ignore the user's drawn area entirely and use the
            # sample data's own extent as the boundary, so it always produces
            # the bundled example no matter where the box was drawn.
            asm = pipeline.assemble_collection(
                p.name, bbox=_sample_bbox(), geojson_obj=None, cfg=cfg,
                overpass_json=str(SAMPLE_JSON))
        else:
            asm = pipeline.assemble_collection(
                p.name, bbox=tuple(p.bbox) if p.bbox else None,
                geojson_obj=p.boundary_geojson, cfg=cfg, overpass_json=None)
        p.assembly = asm
        return asm

    def geojson(self, p: Project) -> dict:
        asm = p.assembly
        return pipeline.collection_to_geojson(asm.fc, asm.crs_info)

    def edit_feature(self, p: Project, fid: str, attributes: dict | None,
                     geometry_wgs: dict | None) -> int:
        asm = p.assembly
        cfg = p.cfg()
        feat = next((f for f in asm.fc.features if f.feature_id == fid), None)
        if feat is None:
            raise KeyError(fid)
        # geometry edit (from the map) -> reproject WGS84 -> working CRS
        if geometry_wgs is not None:
            tr = Transformer.from_crs("EPSG:4326", asm.crs_info.crs, always_xy=True)
            feat.geometry = shp_transform(lambda x, y, z=None: tr.transform(x, y),
                                          shape(geometry_wgs))
        if attributes:
            # if class changed, resync its width rule from config
            if "application_class" in attributes:
                wr = cfg.classification.get("width_rule_by_class", {})
                feat.set("width_rule",
                         wr.get(attributes["application_class"], "side_road"))
            feat.attributes.update(attributes)
        regenerated = 0
        if feat.kind == "road_centerline":
            regenerated = pipeline.regenerate_road_edges(
                asm.fc, fid, cfg.settings, asm.crs_info)
        return regenerated

    def delete_feature(self, p: Project, fid: str) -> None:
        asm = p.assembly
        asm.fc.features = [f for f in asm.fc.features if f.feature_id != fid
                           and f.get("source_feature_id") != fid]

    def add_road(self, p: Project, geometry_wgs: dict, attributes: dict) -> str:
        asm = p.assembly
        cfg = p.cfg()
        tr = Transformer.from_crs("EPSG:4326", asm.crs_info.crs, always_xy=True)
        geom = shp_transform(lambda x, y, z=None: tr.transform(x, y),
                             shape(geometry_wgs))
        attrs = {"source": "manual", "include": True, "reviewed": True}
        attrs.update(attributes or {})
        attrs.setdefault("application_class", "side_road")
        wr = cfg.classification.get("width_rule_by_class", {})
        attrs.setdefault("width_rule", wr.get(attrs["application_class"], "side_road"))
        f = Feature("road_centerline", geom, attrs)
        asm.fc.add(f)
        pipeline.regenerate_road_edges(asm.fc, f.feature_id, cfg.settings, asm.crs_info)
        return f.feature_id

    def export(self, p: Project) -> Path:
        asm = p.assembly
        cfg = p.cfg()
        eid = uuid.uuid4().hex[:8]
        out_dir = PROJECTS_DIR / p.project_id / f"export_{eid}" / "package"
        zip_path = pipeline.write_exports(
            asm.fc, asm.crs_info, p.name, cfg.settings, out_dir, asm.provider_name,
            asm.offset_stats, asm.validation_stats, asm.warnings, bbox=p.bbox,
            source_meta=asm.source_meta, cfg=cfg)
        p.exports[eid] = zip_path
        return zip_path


STORE = ProjectStore()
