"""Pydantic request/response schemas for the API."""
from __future__ import annotations
from typing import Any, Optional
from pydantic import BaseModel


class GeocodeRequest(BaseModel):
    query: str


class CreateProjectRequest(BaseModel):
    name: str
    settings: dict[str, Any] = {}


class BoundaryRequest(BaseModel):
    bbox: Optional[list[float]] = None          # [W,S,E,N]
    geojson: Optional[dict] = None              # polygon Feature/geometry


class FetchRequest(BaseModel):
    use_sample: bool = False


class SettingsRequest(BaseModel):
    settings: dict[str, Any]


class FeatureEdit(BaseModel):
    attributes: Optional[dict[str, Any]] = None
    geometry: Optional[dict] = None             # WGS84 GeoJSON geometry


class AddRoadRequest(BaseModel):
    geometry: dict                              # WGS84 LineString
    attributes: dict[str, Any] = {}
