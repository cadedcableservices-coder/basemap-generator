"""FastAPI application entry point. Serves the API and the single-page web UI."""
from __future__ import annotations
import webbrowser
import threading
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from .api.routes import router
from .core.logging import get_logger

log = get_logger("app")
REPO_ROOT = Path(__file__).resolve().parents[2]
FRONTEND = REPO_ROOT / "frontend"

app = FastAPI(title="Fiber Basemap Generator", version="0.2.0")
app.include_router(router)


@app.get("/", response_class=HTMLResponse)
def index():
    return (FRONTEND / "index.html").read_text(encoding="utf-8")


# static assets (js/css) if any are added later
if (FRONTEND / "static").exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND / "static")), name="static")


def open_browser(url: str = "http://127.0.0.1:8000"):
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
