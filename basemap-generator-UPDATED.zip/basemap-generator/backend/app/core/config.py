"""Load YAML configuration (settings, classification rules, CAD layers).

Config files live in the top-level ``config/`` directory. All settings are
overridable per-project via the exported ``project_settings.json`` so a project
can be regenerated deterministically.
"""
from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any
import copy
import yaml

# repo_root/config  (this file is backend/app/core/config.py -> up 4 = repo root)
REPO_ROOT = Path(__file__).resolve().parents[3]
CONFIG_DIR = REPO_ROOT / "config"


def _load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge ``override`` onto a copy of ``base``."""
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


@dataclass
class AppConfig:
    """Bundle of the three config documents + any per-project overrides."""
    settings: dict[str, Any] = field(default_factory=dict)
    classification: dict[str, Any] = field(default_factory=dict)
    cad_layers: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load(cls, config_dir: Path | None = None,
             overrides: dict[str, Any] | None = None) -> "AppConfig":
        cdir = config_dir or CONFIG_DIR
        settings = _load_yaml(cdir / "default_settings.yaml")
        if overrides:
            settings = deep_merge(settings, overrides)
        return cls(
            settings=settings,
            classification=_load_yaml(cdir / "road_classification.yaml"),
            cad_layers=_load_yaml(cdir / "cad_layers.yaml"),
        )

    def layer_name(self, key: str) -> str:
        return self.cad_layers["layers"][key]["name"]

    def layer_aci(self, key: str) -> int:
        return int(self.cad_layers["layers"][key].get("aci", 7))
