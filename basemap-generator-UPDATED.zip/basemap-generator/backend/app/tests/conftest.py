import sys
from pathlib import Path
# make repo root importable as `backend.app...`
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

import pytest
from backend.app.core.config import AppConfig

REPO = Path(__file__).resolve().parents[3]
SAMPLE = REPO / "sample_data" / "pa_rural_pine_creek.overpass.json"

@pytest.fixture
def cfg():
    return AppConfig.load()

@pytest.fixture
def sample_json():
    return str(SAMPLE)
