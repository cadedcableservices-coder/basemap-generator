"""End-to-end API tests using FastAPI TestClient in offline sample mode."""
import io, zipfile
from fastapi.testclient import TestClient
from backend.app.main import app

BBOX = [-77.276, 41.195, -77.264, 41.207]
client = TestClient(app)


def _new_project_with_features():
    pid = client.post("/api/project", json={"name": "APITest"}).json()["project_id"]
    client.post(f"/api/project/{pid}/boundary", json={"bbox": BBOX})
    r = client.post(f"/api/project/{pid}/fetch-features", json={"use_sample": True})
    return pid, r


def test_health():
    assert client.get("/api/health").json()["status"] == "ok"


def test_index_served():
    r = client.get("/")
    assert r.status_code == 200 and "Fiber Basemap Generator" in r.text


def test_generate_returns_features_and_summary():
    pid, r = _new_project_with_features()
    assert r.status_code == 200, r.text
    s = r.json()["summary"]
    assert s["road_edges"] == 10 and s["failed_offsets"] == 0
    assert s["buildings"] == 2 and s["water"] >= 2 and s["crs_epsg"] == 2271
    kinds = {f["properties"]["kind"] for f in r.json()["geojson"]["features"]}
    assert {"road_edge", "road_centerline", "road_label", "building"} <= kinds


def test_geocode_endpoint_ok_offline():
    r = client.post("/api/geocode", json={"query": "Jersey Shore PA"})
    assert r.status_code == 200 and "results" in r.json()


def test_reclassify_regenerates_edges():
    pid, r = _new_project_with_features()
    smith = next(f for f in r.json()["geojson"]["features"]
                 if f["properties"]["kind"] == "road_centerline"
                 and f["properties"]["road_name"] == "Smith Hill Rd")
    fid = smith["properties"]["feature_id"]
    resp = client.patch(f"/api/project/{pid}/features/{fid}",
                        json={"attributes": {"application_class": "main_road"}})
    assert resp.status_code == 200
    edges = [f for f in resp.json()["geojson"]["features"]
             if f["properties"]["kind"] == "road_edge"
             and f["properties"]["source_feature_id"] == fid]
    assert len(edges) == 2 and all(e["properties"]["width_feet"] == 20 for e in edges)


def test_include_toggle_and_delete():
    pid, r = _new_project_with_features()
    road = next(f for f in r.json()["geojson"]["features"]
                if f["properties"]["kind"] == "road_centerline")
    fid = road["properties"]["feature_id"]
    off = client.patch(f"/api/project/{pid}/features/{fid}",
                       json={"attributes": {"include": False}}).json()["geojson"]
    st = next(f["properties"]["status"] for f in off["features"]
              if f["properties"]["feature_id"] == fid)
    assert st == "excluded"
    d = client.delete(f"/api/project/{pid}/features/{fid}").json()["geojson"]
    assert not any(f["properties"]["feature_id"] == fid for f in d["features"])


def test_settings_change_reassembles():
    pid, _ = _new_project_with_features()
    r = client.put(f"/api/project/{pid}/settings",
                   json={"settings": {"width_interpretation": "edge_offset"}})
    assert r.status_code == 200
    gj = client.get(f"/api/project/{pid}/features").json()
    assert any(f["properties"]["kind"] == "road_edge" for f in gj["features"])


def test_export_and_download():
    pid, _ = _new_project_with_features()
    exp = client.post(f"/api/project/{pid}/export").json()
    dl = client.get(exp["download_url"])
    assert dl.status_code == 200
    names = zipfile.ZipFile(io.BytesIO(dl.content)).namelist()
    assert any(n.endswith(".dxf") for n in names)
    assert any(n.endswith(".gpkg") for n in names)
    assert any(n.endswith(".prj") for n in names)
    assert any("QC_Report.html" in n for n in names)
