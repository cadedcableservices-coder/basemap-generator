"""End-to-end: sample Overpass JSON -> full pipeline -> reopen exports."""
import geopandas as gpd
import ezdxf
import pyogrio
from backend.app import pipeline

BBOX = (-77.276, 41.195, -77.264, 41.207)

def _run(tmp_path, sample_json, overrides=None):
    return pipeline.run("ITest", bbox=BBOX, overpass_json=sample_json,
                        overrides=overrides or {}, out_dir=str(tmp_path/"out"))

def test_pipeline_runs_and_counts(tmp_path, sample_json):
    r = _run(tmp_path, sample_json)
    cls = r.fc.of_kind("road_centerline")
    included = [f for f in cls if f.get("include", True)]
    assert len(cls) == 6                       # 6 fetched (track retained)
    assert len(included) == 5                   # track excluded from output
    assert r.offset_stats.edges_created == 10 # 5 roads x 2 edges
    assert r.offset_stats.failed == 0
    assert r.crs_info.epsg == 2271 and r.crs_info.is_feet

def test_exports_reopen(tmp_path, sample_json):
    r = _run(tmp_path, sample_json)
    out = tmp_path/"out"
    gpkg = out/"GIS"/"ITest_Basemap.gpkg"
    layers = [l[0] for l in pyogrio.list_layers(gpkg)]
    assert "BASE_ROAD_EDGE" in layers and "BASE_BUILDING" in layers
    edges = gpd.read_file(gpkg, layer="BASE_ROAD_EDGE")
    assert edges.crs.to_epsg() == 2271 and len(edges) == 10
    # DXF reopens with expected layers
    doc = ezdxf.readfile(str(out/"CAD"/"ITest_Basemap.dxf"))
    lyrs = {e.dxf.layer for e in doc.modelspace()}
    assert {"BASE_ROAD_EDGE","BASE_ROAD_CENTERLINE","BASE_STATE_ROUTE_LABEL"} <= lyrs
    # shapefile .prj present
    prj = list((out/"GIS"/"Shapefiles").rglob("*.prj"))
    assert prj, "expected .prj sidecar files"
    # QC report + attribution present
    assert (out/"Reports"/"QC_Report.html").exists()
    assert (out/"ATTRIBUTION.txt").exists()

def test_edge_offset_interpretation(tmp_path, sample_json):
    # edge_offset: main road 20 ft => edge 20 ft from centerline (not 10)
    r = _run(tmp_path, sample_json, overrides={"width_interpretation":"edge_offset"})
    cl = [f for f in r.fc.of_kind("road_centerline") if f.get("route_ref")=="PA 44"][0]
    edges = [f for f in r.fc.of_kind("road_edge") if f.get("route_ref")=="PA 44"]
    mid = cl.geometry.interpolate(0.5, normalized=True)
    assert all(abs(e.geometry.distance(mid)-20) < 0.5 for e in edges)

def test_bbox_only_empty_source(tmp_path):
    # empty Overpass doc -> pipeline completes with zero features, no crash
    import json
    empty = tmp_path/"empty.json"
    empty.write_text(json.dumps({"version":0.6,"elements":[]}))
    r = pipeline.run("Empty", bbox=BBOX, overpass_json=str(empty),
                     out_dir=str(tmp_path/"out2"))
    assert r.offset_stats.edges_created == 0
    assert r.export_zip.exists()

def test_state_route_detected_and_labeled(tmp_path, sample_json):
    r = _run(tmp_path, sample_json)
    srs = [f for f in r.fc.of_kind("road_centerline")
           if f.get("application_class")=="state_route"]
    assert {f.get("route_ref") for f in srs} == {"PA 44","US 15"}
    labels = [f.get("label_text") for f in r.fc.of_kind("road_label")
              if f.get("is_state_route")]
    assert any("PA 44" in (t or "") for t in labels)
