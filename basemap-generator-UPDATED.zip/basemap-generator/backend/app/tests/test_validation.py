from shapely.geometry import Polygon
from backend.app.models.features import Feature, FeatureCollection
from backend.app.services.validation import validate_and_repair

def test_bowtie_repaired():
    bowtie = Polygon([(0,0),(2,2),(2,0),(0,2)])  # self-intersecting
    assert not bowtie.is_valid
    fc = FeatureCollection(); fc.add(Feature("building", bowtie, {}))
    stats = validate_and_repair(fc)
    assert stats.invalid_found == 1 and stats.repaired == 1
    assert fc.features[0].geometry.is_valid
