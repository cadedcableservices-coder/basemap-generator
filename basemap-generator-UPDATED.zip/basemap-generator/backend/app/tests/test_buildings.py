from shapely.geometry import Polygon
from backend.app.models.features import Feature, FeatureCollection
from backend.app.services.buildings import process_buildings

def _fc(poly):
    fc = FeatureCollection()
    fc.add(Feature("building", poly, {"building": "yes"}))
    return fc

def test_bbox_mode_makes_rectangle():
    L = Polygon([(0,0),(10,0),(10,5),(5,8),(0,5)])
    fc=_fc(L)
    process_buildings(fc, {"buildings":{"mode":"bbox","min_area_sqft":1}})
    g = fc.of_kind("building")[0].geometry
    assert len(g.exterior.coords) == 5  # closed rectangle

def test_min_area_drop():
    small = Polygon([(0,0),(2,0),(2,2),(0,2)])  # 4 sqft
    fc=_fc(small)
    process_buildings(fc, {"buildings":{"mode":"footprint","min_area_sqft":120}})
    assert fc.of_kind("building")[0].get("include") is False

def test_rotated_rect_area_geq_footprint():
    from shapely import minimum_rotated_rectangle
    L = Polygon([(0,0),(10,0),(10,5),(0,5)])
    fc=_fc(L)
    process_buildings(fc, {"buildings":{"mode":"rotated_rect","min_area_sqft":1}})
    assert fc.of_kind("building")[0].geometry.area >= L.area - 1e-6
