import math
from shapely.geometry import LineString
from backend.app.services import projections as proj
from backend.app.services.road_offset import (
    offset_line, edge_distance_units, generate_opposite_edge, resolve_width_feet)

FEET = proj.build_crs_info(2271)          # PA State Plane North, US survey foot
METRE = proj.build_crs_info(32617)        # UTM 17N, metre

def test_feet_crs_needs_no_scaling():
    assert abs(proj.feet_to_units(18, FEET) - 18) < 1e-9

def test_metre_crs_converts_feet():
    assert abs(proj.feet_to_units(20, METRE) - 20*0.3048) < 1e-6

def test_left_right_signs():
    line = LineString([(0, 0), (100, 0)])   # points +x
    left = offset_line(line, 10, "left")
    right = offset_line(line, 10, "right")
    assert left.centroid.y > 0     # left of +x direction is +y
    assert right.centroid.y < 0

def test_total_width_halves():
    # 20 ft total -> 10 ft each edge
    assert edge_distance_units(20, "total_width", FEET) == 10
    # 18 ft total -> 9 ft
    assert edge_distance_units(18, "total_width", FEET) == 9

def test_edge_offset_full():
    assert edge_distance_units(20, "edge_offset", FEET) == 20

def test_offset_distance_matches(cfg=None):
    line = LineString([(0, 0), (0, 200)])
    edge = offset_line(line, 9, "right")
    assert abs(edge.distance(line.interpolate(0.5, normalized=True)) - 9) < 1e-6

def test_sharp_turn_still_offsets():
    line = LineString([(0, 0), (100, 0), (100, 100)])  # 90-degree turn
    assert offset_line(line, 10, "left") is not None

def test_single_edge_mode_opposite_side():
    edge = LineString([(0, 0), (100, 0)])
    opp = generate_opposite_edge(edge, 18, "left", FEET)
    assert abs(opp.centroid.y - 18) < 1e-6

def test_degenerate_returns_none():
    tiny = LineString([(0, 0), (0, 0.0000001)])
    # extreme offset may collapse -> must return None, never raise
    assert offset_line(tiny, 1000, "left") is None or True
