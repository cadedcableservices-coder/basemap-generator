from backend.app.services import projections as proj

PRESETS = {"pa_state_plane_north": 2271, "pa_state_plane_south": 2272}

def test_pa_north_selected():
    info = proj.recommend_crs((-77.27, 41.20), presets=PRESETS)
    assert info.epsg == 2271 and info.is_feet

def test_pa_south_selected():
    info = proj.recommend_crs((-75.16, 39.95), presets=PRESETS)  # Philadelphia
    assert info.epsg == 2272

def test_utm_fallback_outside_pa():
    info = proj.recommend_crs((-104.99, 39.74), presets=PRESETS)  # Denver
    assert info.epsg in (32613,) and not info.is_feet

def test_geographic_crs_warns():
    info = proj.build_crs_info(4326)
    assert any("geographic" in w.lower() for w in info.warnings)
