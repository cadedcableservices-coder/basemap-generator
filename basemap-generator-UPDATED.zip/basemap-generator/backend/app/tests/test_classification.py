from backend.app.services.road_classification import RoadClassifier

def mk(cfg, **attrs):
    return RoadClassifier(cfg.classification, cfg.settings).classify_one(attrs)

def test_residential_is_side_road(cfg):
    assert mk(cfg, highway_class="residential")["application_class"] == "side_road"

def test_service_alley_is_alley(cfg):
    r = mk(cfg, highway_class="service", service="alley")
    assert r["application_class"] == "alley"

def test_secondary_is_main_road(cfg):
    assert mk(cfg, highway_class="secondary")["application_class"] == "main_road"

def test_state_route_by_ref_patterns(cfg):
    for ref in ["PA 44", "PA-44", "SR 44", "US 15", "I-80", "I 80"]:
        r = mk(cfg, highway_class="secondary", route_ref=ref)
        assert r["application_class"] == "state_route", ref

def test_state_route_by_relation(cfg):
    r = mk(cfg, highway_class="residential", route_relation=True)
    assert r["application_class"] == "state_route"

def test_name_alone_is_not_state_route(cfg):
    r = mk(cfg, highway_class="residential", road_name="State Route Diner Rd")
    assert r["application_class"] != "state_route"

def test_unknown_flagged(cfg):
    r = mk(cfg, highway_class="bogus_tag")
    assert r["application_class"] == "unknown"
    assert "review" in r["notes"].lower()

def test_track_excluded_by_default(cfg):
    r = mk(cfg, highway_class="track")
    assert r["include"] is False

def test_width_rule_mapping(cfg):
    assert mk(cfg, highway_class="residential")["width_rule"] == "side_road"
    assert mk(cfg, highway_class="primary")["width_rule"] == "main_road"
    assert mk(cfg, route_ref="PA 44", highway_class="secondary")["width_rule"] == "main_road"
