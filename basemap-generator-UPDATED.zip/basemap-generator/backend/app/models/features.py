"""In-memory feature model shared across the pipeline.

A ``Feature`` is a thin, source-agnostic container: a Shapely geometry (in
whatever CRS the pipeline currently holds) plus an attribute dict. Keeping a
single flat model means providers, geometry services and exporters all speak
the same language, satisfying the modular-provider requirement.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import itertools

from shapely.geometry.base import BaseGeometry

_id_counter = itertools.count(1)


def new_feature_id(prefix: str = "f") -> str:
    return f"{prefix}{next(_id_counter):06d}"


# Canonical attribute fields for a road (per spec section 4).
ROAD_FIELDS = [
    "feature_id", "source", "source_id", "road_name", "route_ref",
    "highway_class", "application_class", "width_rule", "width_feet",
    "include", "reviewed", "notes",
]

APPLICATION_CLASSES = {"alley", "side_road", "main_road", "state_route", "unknown"}


@dataclass
class Feature:
    kind: str                       # road_centerline | road_edge | road_label |
                                    # stream | river | ditch | drain | water_body |
                                    # building | project_boundary
    geometry: BaseGeometry
    attributes: dict[str, Any] = field(default_factory=dict)
    feature_id: str = field(default_factory=lambda: new_feature_id())

    def get(self, key: str, default: Any = None) -> Any:
        return self.attributes.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.attributes[key] = value


@dataclass
class FeatureCollection:
    """Mutable set of features + free-form metadata (counters, warnings, CRS)."""
    features: list[Feature] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)

    def add(self, f: Feature) -> Feature:
        self.features.append(f)
        return f

    def of_kind(self, *kinds: str) -> list[Feature]:
        return [f for f in self.features if f.kind in kinds]

    def __len__(self) -> int:
        return len(self.features)
