"""Pipeline orchestration, shared by the CLI and the web API.

Public building blocks:
  assemble_collection()  boundary+data -> classified, projected, offset FeatureCollection
  collection_to_geojson() working-CRS features -> WGS84 GeoJSON for the map
  regenerate_road_edges() rebuild one road's edges after an edit
  write_exports()         FeatureCollection -> DXF/GPKG/SHP/reports + ZIP
  run()                   convenience: assemble + write_exports (used by the CLI)
"""
from __future__ import annotations
import json
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pyproj import Transformer
from shapely.geometry import box, shape, Polygon, LineString, MultiLineString, mapping
from shapely.ops import linemerge, transform as shp_transform

from .core.config import AppConfig
from .core.logging import get_logger
from .models.features import Feature, FeatureCollection
from .providers.osm_overpass import OsmOverpassProvider
from .services import projections as proj
from .services.road_classification import RoadClassifier
from .services.road_offset import (generate_centerline_edges, OffsetStats,
                                    offset_line, edge_distance_units, resolve_width_feet)
from .services.labels import generate_labels
from .services.waterways import process_waterways, process_waterbodies
from .services.buildings import process_buildings
from .services.validation import validate_and_repair
from .services.export_dxf import export_dxf
from .services.export_geopackage import export_geopackage
from .services.export_shapefile import export_shapefiles
from .services import qc_report

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Assembly
# ---------------------------------------------------------------------------
@dataclass
class Assembly:
    fc: FeatureCollection
    crs_info: proj.CrsInfo
    offset_stats: OffsetStats
    validation_stats: Any
    warnings: list[str] = field(default_factory=list)
    provider_name: str = ""
    boundary_area_sqft: float = 0.0
    source_meta: dict = field(default_factory=dict)


def boundary_polygon(bbox=None, geojson_path=None, geojson_obj=None) -> Polygon:
    if geojson_obj is not None:
        gj = geojson_obj
    elif geojson_path:
        gj = json.loads(Path(geojson_path).read_text(encoding="utf-8"))
    else:
        gj = None
    if gj is not None:
        if gj.get("type") == "FeatureCollection":
            geom = gj["features"][0]["geometry"]
        elif gj.get("type") == "Feature":
            geom = gj["geometry"]
        else:
            geom = gj
        return shape(geom)
    if bbox:
        w, s, e, n = bbox
        return box(w, s, e, n)
    raise ValueError("Provide bbox, geojson_path, or geojson_obj")


def _clip(geom, clip_poly):
    try:
        c = geom.intersection(clip_poly)
        return None if c.is_empty else c
    except Exception:
        return geom


def _merge_contiguous(fc: FeatureCollection) -> None:
    groups: dict[tuple, list[Feature]] = {}
    for f in fc.of_kind("road_centerline"):
        key = (f.get("road_name"), f.get("application_class"), f.get("route_ref"))
        groups.setdefault(key, []).append(f)
    for _key, feats in groups.items():
        if len(feats) < 2:
            continue
        merged = linemerge([f.geometry for f in feats
                            if isinstance(f.geometry, LineString)])
        if isinstance(merged, LineString):
            feats[0].geometry = merged
            for extra in feats[1:]:
                if extra in fc.features:
                    fc.features.remove(extra)


def assemble_collection(project_name: str, *, bbox=None, geojson_path=None,
                        geojson_obj=None, cfg: AppConfig | None = None,
                        overrides: dict[str, Any] | None = None,
                        overpass_json: str | None = None,
                        config_dir: Path | None = None) -> Assembly:
    cfg = cfg or AppConfig.load(config_dir=config_dir, overrides=overrides)
    settings = cfg.settings
    warnings: list[str] = []

    bpoly = boundary_polygon(bbox=bbox, geojson_path=geojson_path, geojson_obj=geojson_obj)
    wgs_bounds = bpoly.bounds
    if overpass_json:
        provider = OsmOverpassProvider.from_overpass_json(overpass_json, settings=settings)
    else:
        provider = OsmOverpassProvider(settings=settings)
        provider.prime(provider.load_doc(wgs_bounds))

    fc = FeatureCollection()
    for f in provider.fetch_roads(wgs_bounds):
        f.attributes.setdefault("source", provider.name)
        fc.add(f)
    for f in provider.fetch_waterways(wgs_bounds):
        fc.add(f)
    for f in provider.fetch_waterbodies(wgs_bounds):
        fc.add(f)
    for f in provider.fetch_buildings(wgs_bounds):
        fc.add(f)
    fc.add(Feature("project_boundary", bpoly, {"source": provider.name, "include": True}))

    centroid = (bpoly.centroid.x, bpoly.centroid.y)
    if settings.get("crs_mode") == "epsg" and settings.get("crs_epsg"):
        crs_info = proj.build_crs_info(int(settings["crs_epsg"]))
    else:
        crs_info = proj.recommend_crs(centroid, wgs_bounds,
                                      presets=settings.get("crs_presets"))
    warnings.extend(crs_info.warnings)

    proj.reproject_collection(fc, crs_info, src=proj.WGS84)
    fc.meta["crs_info"] = crs_info
    clip_poly = next(f.geometry for f in fc.features if f.kind == "project_boundary")
    boundary_area_sqft = clip_poly.area if crs_info.is_feet else clip_poly.area / (0.3048 ** 2)

    RoadClassifier(cfg.classification, settings).classify(fc.of_kind("road_centerline"))
    if settings.get("merge_contiguous", True):
        _merge_contiguous(fc)

    buffer_units = proj.feet_to_units(float(settings.get("boundary_buffer_ft", 100)), crs_info)
    clip_buffered = clip_poly.buffer(buffer_units)
    for f in list(fc.features):
        if f.kind in ("road_centerline", "waterway", "water_body", "building"):
            clipped = _clip(f.geometry, clip_buffered)
            if clipped is None:
                fc.features.remove(f)
            else:
                if isinstance(clipped, MultiLineString):
                    clipped = max(clipped.geoms, key=lambda g: g.length)
                f.geometry = clipped

    generate_labels(fc, min_spacing_units=proj.feet_to_units(150, crs_info))
    offset_stats = generate_centerline_edges(fc, settings, crs_info)
    process_waterways(fc, settings)
    process_waterbodies(fc, settings)
    process_buildings(fc, settings)
    validation_stats = validate_and_repair(fc)

    return Assembly(fc=fc, crs_info=crs_info, offset_stats=offset_stats,
                    validation_stats=validation_stats, warnings=warnings,
                    provider_name=provider.name, boundary_area_sqft=boundary_area_sqft,
                    source_meta={"bbox_wgs84": list(wgs_bounds),
                                 "elements_source": overpass_json or "live overpass"})


# ---------------------------------------------------------------------------
# Map serialization + editing
# ---------------------------------------------------------------------------
def feature_status(f: Feature) -> str:
    if not f.get("include", True):
        return "excluded"          # gray
    if f.get("application_class") == "unknown":
        return "failed"            # red
    notes = (f.get("notes", "") or "").lower()
    if "review" in notes:
        return "needs_review"      # yellow
    if f.get("reviewed"):
        return "reviewed"          # green
    if f.kind in ("road_centerline", "road_edge"):
        return "needs_review"      # roads default to needs-review until confirmed
    return "reviewed"


_GJ_PROPS = ["road_name", "route_ref", "application_class", "highway_class",
             "width_rule", "width_feet", "include", "reviewed", "notes",
             "edge_side", "label_text", "angle", "is_state_route",
             "waterway_type", "building_repr", "area_sqft", "source_id",
             "source_feature_id"]


def collection_to_geojson(fc: FeatureCollection, crs_info: proj.CrsInfo,
                          include_excluded: bool = True) -> dict:
    """Serialize working-CRS features to WGS84 GeoJSON for the web map."""
    from .services.layers import layer_key_for
    tr = Transformer.from_crs(crs_info.crs, "EPSG:4326", always_xy=True)
    feats = []
    for f in fc.features:
        if not include_excluded and not f.get("include", True):
            continue
        geom_wgs = shp_transform(lambda x, y, z=None: tr.transform(x, y), f.geometry)
        props = {k: f.attributes.get(k) for k in _GJ_PROPS}
        props.update({"feature_id": f.feature_id, "kind": f.kind,
                      "layer_key": layer_key_for(f), "status": feature_status(f)})
        feats.append({"type": "Feature", "geometry": mapping(geom_wgs),
                      "properties": props})
    return {"type": "FeatureCollection", "features": feats}


def regenerate_road_edges(fc: FeatureCollection, centerline_id: str,
                          settings: dict, crs_info: proj.CrsInfo) -> int:
    """Remove and rebuild the two edges belonging to one centerline."""
    road = next((f for f in fc.of_kind("road_centerline")
                 if f.feature_id == centerline_id), None)
    if road is None:
        return 0
    fc.features = [f for f in fc.features
                   if not (f.kind == "road_edge"
                           and f.get("source_feature_id") == centerline_id)]
    if not road.get("include", True) or not isinstance(road.geometry, LineString):
        return 0
    width_ft = resolve_width_feet(road.get("width_rule", "side_road"), settings)
    road.set("width_feet", width_ft)
    dist = edge_distance_units(width_ft, settings.get("width_interpretation", "total_width"),
                               crs_info)
    made = 0
    for side in ("left", "right"):
        edge = offset_line(road.geometry, dist, side)
        if edge is None:
            continue
        fc.add(Feature("road_edge", edge, {
            "source_feature_id": road.feature_id, "road_name": road.get("road_name"),
            "route_ref": road.get("route_ref"),
            "application_class": road.get("application_class"),
            "width_feet": width_ft, "edge_side": side, "include": True}))
        made += 1
    return made


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------
def write_exports(fc: FeatureCollection, crs_info: proj.CrsInfo, project_name: str,
                  settings: dict, out_dir: str | Path, provider_name: str,
                  offset_stats, validation_stats, warnings: list[str],
                  bbox=None, source_meta: dict | None = None,
                  cfg: AppConfig | None = None) -> Path:
    cfg = cfg or AppConfig.load(overrides=None)
    out_dir = Path(out_dir)
    if out_dir.exists():
        try:
            shutil.rmtree(out_dir)
        except (PermissionError, OSError) as exc:
            log.warning("Could not fully clear %s (%s); overwriting.", out_dir, exc)
    safe = project_name.replace(" ", "_")
    cad_dir, gis_dir = out_dir / "CAD", out_dir / "GIS"
    shp_dir, reports_dir = gis_dir / "Shapefiles", out_dir / "Reports"
    settings_dir = out_dir / "Settings"
    for d in (cad_dir, gis_dir, shp_dir, reports_dir, settings_dir):
        d.mkdir(parents=True, exist_ok=True)

    export_dxf(fc, cad_dir / f"{safe}_Basemap.dxf", cfg)
    export_geopackage(fc, gis_dir / f"{safe}_Basemap.gpkg", cfg)
    export_shapefiles(fc, shp_dir, cfg)

    (settings_dir / "project_settings.json").write_text(
        json.dumps({"project_name": project_name, "bbox": bbox,
                    "settings": settings, "crs_epsg": crs_info.epsg}, indent=2),
        encoding="utf-8")
    (out_dir / "ATTRIBUTION.txt").write_text(
        "Data (c) OpenStreetMap contributors, licensed under the Open Database "
        "License (ODbL) 1.0. https://www.openstreetmap.org/copyright\n"
        f"Provider: {provider_name}\n", encoding="utf-8")

    boundary = next((f for f in fc.features if f.kind == "project_boundary"), None)
    area = (boundary.geometry.area if boundary and crs_info.is_feet
            else (boundary.geometry.area / (0.3048 ** 2) if boundary else 0))
    qc = qc_report.collect_qc(fc, project_name, provider_name, area,
                              f"EPSG:{crs_info.epsg} ({crs_info.unit_name})",
                              offset_stats, validation_stats, warnings)
    qc_report.write_reports(qc, reports_dir,
                            source_meta=source_meta or {},
                            projection_meta={"working_epsg": crs_info.epsg,
                                             "unit": crs_info.unit_name,
                                             "feet_per_unit": crs_info.feet_per_unit,
                                             "boundary_area_sqft": round(area, 1)})

    zip_path = out_dir.parent / f"{safe}_Basemap.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in out_dir.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(out_dir.parent))
    log.info("Export package: %s", zip_path)
    return zip_path


# ---------------------------------------------------------------------------
# CLI convenience
# ---------------------------------------------------------------------------
@dataclass
class PipelineResult:
    fc: FeatureCollection
    crs_info: proj.CrsInfo
    offset_stats: OffsetStats
    validation_stats: Any
    warnings: list[str] = field(default_factory=list)
    export_zip: Path | None = None


def run(project_name: str, *, bbox=None, geojson_path=None,
        overrides: dict[str, Any] | None = None, overpass_json: str | None = None,
        out_dir: str | Path = "output", config_dir: Path | None = None) -> PipelineResult:
    cfg = AppConfig.load(config_dir=config_dir, overrides=overrides)
    asm = assemble_collection(project_name, bbox=bbox, geojson_path=geojson_path,
                              cfg=cfg, overpass_json=overpass_json)
    zip_path = write_exports(asm.fc, asm.crs_info, project_name, cfg.settings, out_dir,
                             asm.provider_name, asm.offset_stats, asm.validation_stats,
                             asm.warnings, bbox=bbox, source_meta=asm.source_meta, cfg=cfg)
    return PipelineResult(fc=asm.fc, crs_info=asm.crs_info, offset_stats=asm.offset_stats,
                          validation_stats=asm.validation_stats, warnings=asm.warnings,
                          export_zip=zip_path)
