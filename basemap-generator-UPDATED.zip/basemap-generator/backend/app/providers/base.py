"""Abstract data-provider interface.

Every source (OSM/Overpass, USGS NHD, a county ArcGIS REST service, an uploaded
shapefile ...) implements this contract. The rest of the pipeline never imports
a concrete provider directly, so new sources are added without touching core
code (spec section 5).

Geometry returned by providers is ALWAYS lon/lat WGS84 (EPSG:4326). Reprojection
to a working CRS happens later, in the projections service.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any

from ..models.features import Feature

# A bounding box is (min_lon, min_lat, max_lon, max_lat) in WGS84.
BBox = tuple[float, float, float, float]


class BaseProvider(ABC):
    name: str = "base"

    @abstractmethod
    def search_location(self, query: str) -> list[dict[str, Any]]:
        """Geocode a free-text location to candidate results (lon/lat + bbox)."""

    @abstractmethod
    def fetch_roads(self, bbox: BBox) -> list[Feature]:
        ...

    @abstractmethod
    def fetch_waterways(self, bbox: BBox) -> list[Feature]:
        ...

    @abstractmethod
    def fetch_waterbodies(self, bbox: BBox) -> list[Feature]:
        ...

    @abstractmethod
    def fetch_buildings(self, bbox: BBox) -> list[Feature]:
        ...

    def fetch_route_information(self, bbox: BBox) -> dict[str, Any]:
        """Optional: extra route-relation lookups. Default: nothing."""
        return {}

    @abstractmethod
    def normalize_attributes(self, raw_tags: dict[str, Any]) -> dict[str, Any]:
        """Map source-specific tags to the pipeline's canonical attribute names."""
