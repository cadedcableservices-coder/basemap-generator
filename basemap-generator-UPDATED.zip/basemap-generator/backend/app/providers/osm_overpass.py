"""OpenStreetMap provider using the Overpass API.

Design notes
------------
* Fetching uses ``out geom;`` so each element carries an inline geometry list;
  we never have to resolve node ids separately.
* Requests are cached on disk keyed by the exact query, so re-running a project
  with the same boundary does not re-hit Overpass (spec section 17).
* Retries use exponential backoff and fall back across endpoints.
* ``from_overpass_json`` lets tests and the offline demo feed a saved response,
  so the pipeline is provable without internet access.
"""
from __future__ import annotations
import hashlib
import json
import time
from pathlib import Path
from typing import Any

from shapely.geometry import LineString, Polygon, Point

from .base import BaseProvider, BBox
from ..models.features import Feature
from ..core.logging import get_logger

log = get_logger(__name__)


class OverpassError(RuntimeError):
    pass


class OsmOverpassProvider(BaseProvider):
    name = "osm_overpass"

    def __init__(self, settings: dict[str, Any] | None = None,
                 cache_dir: str | Path | None = None):
        s = (settings or {}).get("overpass", {})
        self.endpoints: list[str] = s.get(
            "endpoints", ["https://overpass-api.de/api/interpreter"])
        self.timeout_s: int = int(s.get("timeout_s", 180))
        self.max_retries: int = int(s.get("max_retries", 4))
        self.backoff_base_s: float = float(s.get("backoff_base_s", 2.0))
        self.cache_dir = Path(cache_dir or s.get("cache_dir", ".cache/overpass"))
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Query building
    # ------------------------------------------------------------------
    @staticmethod
    def _bbox_clause(bbox: BBox) -> str:
        # Overpass expects (south, west, north, east) == (minlat,minlon,maxlat,maxlon)
        w, s, e, n = bbox
        return f"({s},{w},{n},{e})"

    def build_query(self, bbox: BBox) -> str:
        b = self._bbox_clause(bbox)
        # One query pulls everything we need; relations included for route refs.
        return f"""[out:json][timeout:{self.timeout_s}];
(
  way["highway"]{b};
  way["waterway"]{b};
  way["natural"="water"]{b};
  way["water"]{b};
  way["building"]{b};
  relation["type"="route"]["route"="road"]{b};
);
out geom;
"""

    # ------------------------------------------------------------------
    # Network fetch (with cache + retry/backoff + endpoint fallback)
    # ------------------------------------------------------------------
    def _cache_path(self, query: str) -> Path:
        h = hashlib.sha256(query.encode("utf-8")).hexdigest()[:20]
        return self.cache_dir / f"{h}.json"

    # A descriptive User-Agent is REQUIRED: public Overpass/Nominatim servers
    # (behind mod_security / WAFs) reject requests that use the default
    # "python-requests/x" agent with HTTP 406/403. This was the cause of the
    # "406 Not Acceptable" errors.
    HEADERS = {
        "User-Agent": "basemap-generator/0.2 (fiber drafting tool; contact: caded@cable-services.com)",
        "Accept": "application/json,*/*",
        "Referer": "https://localhost/basemap-generator",
    }

    def fetch_raw(self, bbox: BBox, use_cache: bool = True) -> dict[str, Any]:
        query = self.build_query(bbox)
        cache = self._cache_path(query)
        if use_cache and cache.exists():
            log.info("Overpass cache hit: %s", cache.name)
            return json.loads(cache.read_text(encoding="utf-8"))

        import requests  # imported lazily so offline use needs no network stack
        session = requests.Session()
        session.headers.update(self.HEADERS)
        last_err: Exception | None = None
        # try each endpoint in order, then loop again for the retry budget
        n = max(len(self.endpoints), 1)
        for attempt in range(1, self.max_retries * n + 1):
            endpoint = self.endpoints[(attempt - 1) % n]
            try:
                log.info("Overpass request (attempt %d) -> %s", attempt, endpoint)
                resp = session.post(endpoint, data={"data": query},
                                    timeout=self.timeout_s + 10)
                # some servers/WAFs 406 a form POST; retry once as a GET query
                if resp.status_code == 406:
                    log.warning("406 on POST; retrying %s as GET", endpoint)
                    resp = session.get(endpoint, params={"data": query},
                                       timeout=self.timeout_s + 10)
                if resp.status_code == 200:
                    doc = resp.json()
                    cache.write_text(json.dumps(doc), encoding="utf-8")
                    return doc
                # 406/403/429/5xx -> try the next endpoint after a backoff
                raise OverpassError(
                    f"HTTP {resp.status_code} from {endpoint}: "
                    f"{resp.text[:120].strip()}")
            except Exception as exc:
                last_err = exc
                wait = min(self.backoff_base_s * (2 ** ((attempt - 1) // n)), 30)
                log.warning("Overpass attempt %d failed (%s); next in %.1fs",
                            attempt, exc, wait)
                time.sleep(wait)
        raise OverpassError(
            f"Overpass unavailable after {self.max_retries * n} attempts: {last_err}")

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------
    @staticmethod
    def _coords(el: dict) -> list[tuple[float, float]]:
        # geometry entries are {"lat":..,"lon":..}; Shapely wants (x=lon, y=lat)
        return [(g["lon"], g["lat"]) for g in el.get("geometry", [])]

    def _route_refs_by_way(self, doc: dict) -> dict[int, dict[str, Any]]:
        """Map way-id -> route relation info so member ways inherit the ref."""
        out: dict[int, dict[str, Any]] = {}
        for el in doc.get("elements", []):
            if el.get("type") != "relation":
                continue
            tags = el.get("tags", {})
            if tags.get("type") != "route":
                continue
            info = {"route_ref": tags.get("ref"),
                    "route_network": tags.get("network"),
                    "route_relation": True}
            for m in el.get("members", []):
                if m.get("type") == "way":
                    out[m["ref"]] = info
        return out

    def normalize_attributes(self, raw_tags: dict[str, Any]) -> dict[str, Any]:
        t = raw_tags or {}
        return {
            "road_name": t.get("name"),
            "route_ref": t.get("ref"),
            "highway_class": t.get("highway"),
            "service": t.get("service"),
            "lanes": t.get("lanes"),
            "width": t.get("width"),
            "surface": t.get("surface"),
            "bridge": t.get("bridge"),
            "tunnel": t.get("tunnel"),
            "layer": t.get("layer"),
            "waterway": t.get("waterway"),
            "natural": t.get("natural"),
            "water": t.get("water"),
            "building": t.get("building"),
        }

    # ---- feature extractors -----------------------------------------
    def _features_from_doc(self, doc: dict, want: str) -> list[Feature]:
        route_map = self._route_refs_by_way(doc)
        feats: list[Feature] = []
        for el in doc.get("elements", []):
            if el.get("type") != "way":
                continue
            tags = el.get("tags", {})
            coords = self._coords(el)
            if len(coords) < 2:
                continue
            attrs = self.normalize_attributes(tags)
            attrs["source"] = self.name
            attrs["source_id"] = f"way/{el['id']}"

            if want == "roads" and "highway" in tags:
                if el["id"] in route_map and not attrs.get("route_ref"):
                    attrs["route_ref"] = route_map[el["id"]].get("route_ref")
                if el["id"] in route_map:
                    attrs["route_relation"] = True
                feats.append(Feature("road_centerline", LineString(coords), attrs))

            elif want == "waterways" and "waterway" in tags:
                feats.append(Feature("waterway", LineString(coords), attrs))

            elif want == "waterbodies" and (
                    tags.get("natural") == "water" or "water" in tags):
                poly = self._as_polygon(coords)
                if poly is not None:
                    feats.append(Feature("water_body", poly, attrs))

            elif want == "buildings" and "building" in tags:
                poly = self._as_polygon(coords)
                if poly is not None:
                    feats.append(Feature("building", poly, attrs))
        return feats

    @staticmethod
    def _as_polygon(coords: list[tuple[float, float]]) -> Polygon | None:
        if len(coords) < 3:
            return None
        if coords[0] != coords[-1]:
            coords = coords + [coords[0]]
        try:
            p = Polygon(coords)
            return p if not p.is_empty else None
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def load_doc(self, bbox: BBox | None, use_cache: bool = True,
                 json_path: str | Path | None = None) -> dict:
        if json_path is not None:
            return json.loads(Path(json_path).read_text(encoding="utf-8"))
        if bbox is None:
            raise ValueError("bbox required when no json_path given")
        return self.fetch_raw(bbox, use_cache=use_cache)

    # cached doc between calls in a single run
    _doc_cache: dict | None = None

    def prime(self, doc: dict) -> None:
        self._doc_cache = doc

    def _doc(self, bbox: BBox) -> dict:
        if self._doc_cache is None:
            self._doc_cache = self.fetch_raw(bbox)
        return self._doc_cache

    def search_location(self, query: str) -> list[dict[str, Any]]:
        """Geocode via Nominatim. Network-dependent; returns [] on failure."""
        try:
            import requests
            r = requests.get("https://nominatim.openstreetmap.org/search",
                             params={"q": query, "format": "jsonv2", "limit": 5},
                             headers={"User-Agent": "basemap-generator/0.1"},
                             timeout=30)
            return r.json() if r.status_code == 200 else []
        except Exception as exc:
            log.warning("Geocode failed: %s", exc)
            return []

    def fetch_roads(self, bbox: BBox) -> list[Feature]:
        return self._features_from_doc(self._doc(bbox), "roads")

    def fetch_waterways(self, bbox: BBox) -> list[Feature]:
        return self._features_from_doc(self._doc(bbox), "waterways")

    def fetch_waterbodies(self, bbox: BBox) -> list[Feature]:
        return self._features_from_doc(self._doc(bbox), "waterbodies")

    def fetch_buildings(self, bbox: BBox) -> list[Feature]:
        return self._features_from_doc(self._doc(bbox), "buildings")

    @classmethod
    def from_overpass_json(cls, path: str | Path,
                           settings: dict[str, Any] | None = None,
                           cache_dir: str | Path | None = None
                           ) -> "OsmOverpassProvider":
        prov = cls(settings=settings, cache_dir=cache_dir)
        prov.prime(json.loads(Path(path).read_text(encoding="utf-8")))
        return prov
