"""Simplify building footprints per the requested representation (spec section 11)."""
from __future__ import annotations
from shapely.geometry import Polygon
from shapely import minimum_rotated_rectangle

from ..models.features import FeatureCollection


def _bbox_polygon(poly: Polygon) -> Polygon:
    minx, miny, maxx, maxy = poly.bounds
    return Polygon([(minx, miny), (maxx, miny), (maxx, maxy), (minx, maxy)])


def process_buildings(fc: FeatureCollection, settings: dict) -> None:
    b = settings.get("buildings", {})
    mode = b.get("mode", "footprint")
    min_area = float(b.get("min_area_sqft", 120))

    if mode == "none":
        for f in fc.of_kind("building"):
            f.set("include", False)
        return

    for f in fc.of_kind("building"):
        poly = f.geometry
        area_sqft = poly.area  # projected feet
        if area_sqft < min_area:
            f.set("include", False)
            f.set("notes", f"building {area_sqft:.0f} sqft < min {min_area}")
            continue
        f.set("include", True)
        f.set("area_sqft", round(area_sqft, 1))
        if mode == "rotated_rect":
            f.geometry = minimum_rotated_rectangle(poly)
            f.set("building_repr", "rotated_rect")
        elif mode == "bbox":
            f.geometry = _bbox_polygon(poly)
            f.set("building_repr", "bbox")
        else:
            f.set("building_repr", "footprint")
