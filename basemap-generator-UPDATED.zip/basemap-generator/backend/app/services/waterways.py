"""Classify and filter water features per the drafter's include/exclude toggles."""
from __future__ import annotations
from ..models.features import Feature, FeatureCollection

STREAMISH = {"stream", "river", "ditch", "drain", "canal"}


def process_waterways(fc: FeatureCollection, settings: dict) -> None:
    w = settings.get("water", {})
    for f in fc.of_kind("waterway"):
        wtype = (f.get("waterway") or "").lower()
        name = f.get("road_name") or f.get("name")
        # refine kind for layering
        if wtype == "river":
            f.kind = "river"
        elif wtype in ("ditch",):
            f.kind = "ditch"
        elif wtype in ("drain",):
            f.kind = "drain"
        else:
            f.kind = "stream"

        include = True
        if wtype == "stream" and not w.get("include_minor_streams", True) and not name:
            include = False
        if wtype == "ditch" and not w.get("include_ditches", False):
            include = False
        if wtype == "drain" and not w.get("include_drains", False):
            include = False
        if not name and not w.get("include_unnamed_water", True):
            include = False
        f.set("include", include)
        f.set("waterway_type", wtype)


def process_waterbodies(fc: FeatureCollection, settings: dict) -> None:
    w = settings.get("water", {})
    min_area = float(w.get("min_pond_area_sqft", 400))
    for f in fc.of_kind("water_body"):
        area_sqft = f.geometry.area  # assumes projected CRS in feet; QC notes unit
        include = True
        if area_sqft < min_area:
            include = False
            f.set("notes", f"small water body {area_sqft:.0f} sqft < {min_area}")
        if not (f.get("road_name") or f.get("name")) and not w.get(
                "include_unnamed_water", True):
            include = False
        f.set("include", include)
