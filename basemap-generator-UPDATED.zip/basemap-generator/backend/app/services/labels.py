"""Build a road-label layer: one label per centerline, text + rotation angle."""
from __future__ import annotations
import math
from shapely.geometry import LineString, Point

from ..models.features import Feature, FeatureCollection


def _label_text(name: str | None, ref: str | None) -> str | None:
    if name and ref:
        return f"{name} / {ref}"
    return name or ref or None


def _angle_deg(line: LineString) -> float:
    """Angle of the segment at the line midpoint, normalized to (-90, 90] so
    text is never upside-down."""
    pt = line.interpolate(0.5, normalized=True)
    d = 0.01 * line.length or 1.0
    a = line.interpolate(max(line.project(pt) - d, 0))
    b = line.interpolate(min(line.project(pt) + d, line.length))
    ang = math.degrees(math.atan2(b.y - a.y, b.x - a.x))
    if ang > 90:
        ang -= 180
    if ang <= -90:
        ang += 180
    return ang


def generate_labels(fc: FeatureCollection, min_spacing_units: float = 150.0) -> None:
    placed: list[Point] = []
    for road in fc.of_kind("road_centerline"):
        if not road.get("include", True):
            continue
        text = _label_text(road.get("road_name"), road.get("route_ref"))
        if not text:
            continue
        if not isinstance(road.geometry, LineString):
            continue
        pt = road.geometry.interpolate(0.5, normalized=True)
        if any(pt.distance(p) < min_spacing_units for p in placed):
            continue
        placed.append(pt)
        is_sr = road.get("application_class") == "state_route"
        fc.add(Feature("road_label", pt, {
            "label_text": text,
            "road_name": road.get("road_name"),
            "route_ref": road.get("route_ref"),
            "angle": round(_angle_deg(road.geometry), 2),
            "source_feature_id": road.feature_id,
            "is_state_route": is_sr,
        }))
