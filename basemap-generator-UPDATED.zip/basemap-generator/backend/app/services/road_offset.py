"""Generate roadway-edge lines from centerlines (Mode A) or a single edge (Mode B).

Width interpretations (spec section 3):
  total_width : the 18/20 ft value is the TOTAL road width; each edge sits
                half that (9/10 ft) from the centerline.            [DEFAULT]
  edge_offset : each edge sits the full 18/20 ft from the centerline.

Offsets are computed in the working (projected) CRS units. Failures (empty or
degenerate offset curves, common on tiny segments or hairpins) are caught,
counted, and the centerline is flagged for manual review rather than dropped.
"""
from __future__ import annotations
from dataclasses import dataclass, field

from shapely.geometry import LineString, MultiLineString
from shapely.geometry.base import BaseGeometry

from ..models.features import Feature, FeatureCollection
from ..core.logging import get_logger
from .projections import CrsInfo, feet_to_units

log = get_logger(__name__)


@dataclass
class OffsetStats:
    edges_created: int = 0
    failed: int = 0
    failed_ids: list[str] = field(default_factory=list)


def resolve_width_feet(width_rule: str, settings: dict) -> float:
    widths = settings.get("widths_feet", {})
    return float(widths.get(width_rule, widths.get("side_road", 18)))


def edge_distance_units(width_feet: float, interpretation: str,
                        crs_info: CrsInfo) -> float:
    """Distance from centerline to one edge, in CRS units."""
    if interpretation == "total_width":
        dist_ft = width_feet / 2.0
    elif interpretation == "edge_offset":
        dist_ft = width_feet
    else:
        raise ValueError(f"unknown width_interpretation '{interpretation}'")
    return feet_to_units(dist_ft, crs_info)


def _clean_offset(geom: BaseGeometry | None) -> LineString | None:
    """Normalize an offset result: pick the longest part, reject empties."""
    if geom is None or geom.is_empty:
        return None
    if isinstance(geom, MultiLineString):
        parts = [g for g in geom.geoms if not g.is_empty]
        if not parts:
            return None
        geom = max(parts, key=lambda g: g.length)
    if isinstance(geom, LineString) and geom.length > 0:
        return geom
    return None


def offset_line(line: LineString, distance_units: float,
                side: str) -> LineString | None:
    """Offset a line to one side. side='left'|'right'.

    Shapely offset_curve: positive distance = left of the line direction,
    negative = right.
    """
    signed = distance_units if side == "left" else -distance_units
    try:
        result = line.offset_curve(signed, join_style="mitre")
    except Exception as exc:
        log.debug("offset_curve error: %s", exc)
        return None
    return _clean_offset(result)


def generate_centerline_edges(fc: FeatureCollection, settings: dict,
                              crs_info: CrsInfo,
                              edge_layer_attr: str = "edge_side") -> OffsetStats:
    """Mode A: for each included centerline create left+right edge features."""
    interp = settings.get("width_interpretation", "total_width")
    stats = OffsetStats()
    for road in list(fc.of_kind("road_centerline")):
        if not road.get("include", True):
            continue
        if not isinstance(road.geometry, LineString):
            continue
        width_ft = resolve_width_feet(road.get("width_rule", "side_road"), settings)
        road.set("width_feet", width_ft)
        dist = edge_distance_units(width_ft, interp, crs_info)

        made = 0
        for side in ("left", "right"):
            edge = offset_line(road.geometry, dist, side)
            if edge is None:
                continue
            attrs = {
                "source_feature_id": road.feature_id,
                "road_name": road.get("road_name"),
                "route_ref": road.get("route_ref"),
                "application_class": road.get("application_class"),
                "width_feet": width_ft,
                edge_layer_attr: side,
            }
            fc.add(Feature("road_edge", edge, attrs))
            made += 1
            stats.edges_created += 1
        if made < 2:
            stats.failed += 1
            stats.failed_ids.append(road.feature_id)
            note = road.get("notes", "")
            road.set("notes", (note + f"; offset produced {made}/2 edges - review")
                     .strip("; "))
            road.set("reviewed", False)
    return stats


def generate_opposite_edge(edge_line: LineString, width_feet: float, side: str,
                           crs_info: CrsInfo) -> LineString | None:
    """Mode B: given ONE roadway edge, generate the opposite edge at the full
    18/20 ft offset on the requested side."""
    dist = feet_to_units(width_feet, crs_info)
    return offset_line(edge_line, dist, side)
