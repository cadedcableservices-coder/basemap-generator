"""Classify road centerlines into application classes and assign width rules.

Driven entirely by config/road_classification.yaml so admins can change mappings
without editing code (spec section 4). State-route detection uses ref patterns
AND route-relation membership -- never the name alone.
"""
from __future__ import annotations
import re
from typing import Any

from ..models.features import Feature
from ..core.logging import get_logger

log = get_logger(__name__)


class RoadClassifier:
    def __init__(self, classification_cfg: dict[str, Any], settings: dict[str, Any]):
        self.cfg = classification_cfg
        self.settings = settings
        self.highway_map: dict[str, str] = classification_cfg.get("highway_class_map", {})
        sr = classification_cfg.get("state_route", {})
        self.ref_patterns = [re.compile(p, re.IGNORECASE)
                             for p in sr.get("ref_patterns", [])]
        self.default_class = classification_cfg.get("default_application_class", "unknown")
        self.width_rule_by_class = classification_cfg.get("width_rule_by_class", {})
        self.include_tracks = bool(settings.get("include_tracks", False))

    # ---- state-route detection --------------------------------------
    def is_state_route(self, attrs: dict[str, Any]) -> bool:
        if attrs.get("route_relation"):
            return True
        ref = attrs.get("route_ref") or ""
        if isinstance(ref, str):
            for pat in self.ref_patterns:
                if pat.search(ref.strip()):
                    return True
        return False

    def classify_one(self, attrs: dict[str, Any]) -> dict[str, Any]:
        highway = (attrs.get("highway_class") or "").strip()
        service = (attrs.get("service") or "").strip()
        notes: list[str] = []

        if self.is_state_route(attrs):
            app_class = "state_route"
        else:
            base = self.highway_map.get(highway, self.default_class)
            # alley special-case: service road tagged service=alley
            if highway == "service" and service == "alley":
                app_class = "alley"
            else:
                app_class = base

        include = True
        if highway == "track" and not self.include_tracks:
            include = False
            notes.append("track excluded (include_tracks=false)")

        if app_class == "unknown":
            notes.append(f"unrecognized highway tag '{highway or 'None'}' - review")

        width_rule = self.width_rule_by_class.get(app_class, "side_road")
        return {
            "application_class": app_class,
            "width_rule": width_rule,
            "include": include,
            "reviewed": False,
            "notes": "; ".join(notes),
            "is_state_route": app_class == "state_route",
        }

    def classify(self, roads: list[Feature]) -> None:
        for f in roads:
            result = self.classify_one(f.attributes)
            f.attributes.update(result)
            if not f.attributes.get("road_name"):
                f.attributes["notes"] = (
                    (f.attributes.get("notes", "") + "; unnamed road").strip("; "))
