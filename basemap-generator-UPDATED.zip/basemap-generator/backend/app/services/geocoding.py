"""Thin geocoding facade (delegates to the active provider)."""
from __future__ import annotations
from ..providers.base import BaseProvider


def geocode(provider: BaseProvider, query: str) -> list[dict]:
    return provider.search_location(query)
