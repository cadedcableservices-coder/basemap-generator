"""Group pipeline features into named output layers (shared by all exporters)."""
from __future__ import annotations
from ..models.features import Feature, FeatureCollection

# pipeline kind -> CAD/GIS layer key (keys resolve to names via cad_layers.yaml)
def layer_key_for(f: Feature) -> str | None:
    k = f.kind
    if k == "road_edge":
        return "road_edge"
    if k == "road_centerline":
        return "road_centerline"
    if k == "road_label":
        return "state_route_label" if f.get("is_state_route") else "road_label"
    if k in ("stream", "ditch", "drain"):
        return "stream"
    if k == "river":
        return "river"
    if k == "water_body":
        return "water_body"
    if k == "building":
        return "building"
    if k == "project_boundary":
        return "project_boundary"
    return None


def grouped_layers(fc: FeatureCollection, include_only: bool = True
                   ) -> dict[str, list[Feature]]:
    out: dict[str, list[Feature]] = {}
    for f in fc.features:
        if include_only and not f.get("include", True):
            continue
        key = layer_key_for(f)
        if key is None:
            continue
        out.setdefault(key, []).append(f)
    return out
