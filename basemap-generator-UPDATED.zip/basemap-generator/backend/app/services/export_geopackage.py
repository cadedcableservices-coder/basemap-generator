"""Export all layers to a single GeoPackage (one layer per feature group)."""
from __future__ import annotations
from pathlib import Path

import geopandas as gpd
from shapely.geometry import mapping  # noqa

from ..models.features import FeatureCollection
from .layers import grouped_layers
from ..core.logging import get_logger

log = get_logger(__name__)

# attribute fields to carry into GIS outputs
_FIELDS = ["feature_id", "source", "source_id", "road_name", "route_ref",
           "highway_class", "application_class", "width_rule", "width_feet",
           "edge_side", "waterway_type", "building_repr", "area_sqft",
           "label_text", "angle", "is_state_route", "include", "reviewed", "notes"]


def _gdf_for(features, epsg):
    rows, geoms = [], []
    for f in features:
        row = {k: f.attributes.get(k) for k in _FIELDS}
        row["feature_id"] = f.feature_id
        rows.append(row)
        geoms.append(f.geometry)
    gdf = gpd.GeoDataFrame(rows, geometry=geoms, crs=f"EPSG:{epsg}")
    return gdf


def export_geopackage(fc: FeatureCollection, out_path: str | Path,
                      cfg) -> Path:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        try:
            out_path.unlink()
        except (PermissionError, OSError):
            pass  # locked mount; GPKG driver will overwrite the layers
    epsg = fc.meta.get("crs_epsg")
    groups = grouped_layers(fc)
    written = 0
    for key, feats in groups.items():
        if not feats:
            continue
        name = cfg.layer_name(key)
        gdf = _gdf_for(feats, epsg)
        gdf.to_file(out_path, layer=name, driver="GPKG")
        written += 1
    log.info("GeoPackage: %d layers -> %s", written, out_path.name)
    return out_path
