"""Export layers to ESRI Shapefiles (one folder per layer, .prj included)."""
from __future__ import annotations
from pathlib import Path

import geopandas as gpd

from ..models.features import FeatureCollection
from .layers import grouped_layers

# shapefile field names limited to 10 chars
_FIELD_MAP = {
    "feature_id": "fid", "source": "source", "source_id": "src_id",
    "road_name": "name", "route_ref": "ref", "highway_class": "hwy_class",
    "application_class": "app_class", "width_feet": "width_ft",
    "edge_side": "edge_side", "waterway_type": "wtr_type",
    "building_repr": "bld_repr", "area_sqft": "area_sqft",
    "label_text": "label", "angle": "angle", "is_state_route": "is_sr",
    "include": "include", "reviewed": "reviewed", "notes": "notes",
}

# subfolder name per layer key
_FOLDER = {
    "road_edge": "Road_Edges", "road_centerline": "Road_Centerlines",
    "road_label": "Road_Labels", "state_route_label": "Road_Labels",
    "stream": "Waterways", "river": "Waterways",
    "water_body": "Water_Bodies", "building": "Buildings",
    "project_boundary": "Project_Boundary",
}


def _gdf(features, epsg):
    rows, geoms = [], []
    for f in features:
        row = {}
        for src, dst in _FIELD_MAP.items():
            if src == "feature_id":
                row[dst] = f.feature_id
            else:
                row[dst] = f.attributes.get(src)
        rows.append(row)
        geoms.append(f.geometry)
    return gpd.GeoDataFrame(rows, geometry=geoms, crs=f"EPSG:{epsg}")


def export_shapefiles(fc: FeatureCollection, out_dir: str | Path, cfg) -> Path:
    out_dir = Path(out_dir)
    epsg = fc.meta.get("crs_epsg")
    groups = grouped_layers(fc)
    for key, feats in groups.items():
        if not feats:
            continue
        folder = out_dir / _FOLDER.get(key, key)
        folder.mkdir(parents=True, exist_ok=True)
        gdf = _gdf(feats, epsg)
        # merge state route labels into Road_Labels file alongside road labels
        shp = folder / f"{cfg.layer_name(key)}.shp"
        gdf.to_file(shp, driver="ESRI Shapefile")
    return out_dir
