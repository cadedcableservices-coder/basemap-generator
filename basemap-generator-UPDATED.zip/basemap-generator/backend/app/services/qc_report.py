"""Assemble QC statistics and render QC_Report.html + supporting text reports."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import html

from ..models.features import FeatureCollection

DISCLAIMER = (
    "This basemap is generated from third-party geographic data and is intended "
    "to assist drafting. It is not a land survey, utility locate, right-of-way "
    "determination, or engineering certification. All information must be "
    "reviewed before being used for construction.")


@dataclass
class QcData:
    project_name: str
    created: str
    boundary_area_sqft: float
    working_crs: str
    source_provider: str
    counts: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    attribution: str = ""


def collect_qc(fc: FeatureCollection, project_name: str, provider: str,
               boundary_area_sqft: float, working_crs: str,
               offset_stats, validation_stats, warnings: list[str]) -> QcData:
    roads = fc.of_kind("road_centerline")
    included = [r for r in roads if r.get("include", True)]
    unknown = [r for r in roads if r.get("application_class") == "unknown"]
    unnamed = [r for r in roads if not r.get("road_name")]
    refs = [r for r in roads if r.get("route_ref")]
    water = fc.of_kind("stream", "river", "ditch", "drain", "water_body")
    buildings = [b for b in fc.of_kind("building") if b.get("include", True)]
    review = [f for f in fc.features
              if (f.get("application_class") == "unknown") or
              ("review" in (f.get("notes", "") or "").lower())]

    counts = {
        "roads_downloaded": len(roads),
        "roads_included": len(included),
        "roads_excluded": len(roads) - len(included),
        "roads_unknown_class": len(unknown),
        "road_edges_created": offset_stats.edges_created,
        "failed_offsets": offset_stats.failed,
        "unnamed_roads": len(unnamed),
        "route_refs_found": len(refs),
        "water_features": len(water),
        "buildings": len(buildings),
        "invalid_geometries": validation_stats.invalid_found,
        "geometries_repaired": validation_stats.repaired,
        "empty_removed": validation_stats.empty_removed,
        "features_needing_review": len(review),
    }
    return QcData(
        project_name=project_name,
        created=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        boundary_area_sqft=boundary_area_sqft,
        working_crs=working_crs,
        source_provider=provider,
        counts=counts,
        warnings=warnings,
        attribution="© OpenStreetMap contributors, ODbL 1.0",
    )


def render_html(qc: QcData) -> str:
    rows = "".join(
        f"<tr><td>{html.escape(k.replace('_',' ').title())}</td>"
        f"<td style='text-align:right'>{v}</td></tr>"
        for k, v in qc.counts.items())
    warns = "".join(f"<li>{html.escape(w)}</li>" for w in qc.warnings) or \
        "<li>None</li>"
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>QC Report - {html.escape(qc.project_name)}</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;margin:2rem;color:#1a1a1a}}
table{{border-collapse:collapse;min-width:420px}}td{{border:1px solid #ccc;padding:4px 10px}}
.disc{{background:#fff4e5;border:1px solid #e0a96d;padding:12px;margin-top:1rem}}
h1{{font-size:1.4rem}}code{{background:#f0f0f0;padding:1px 4px}}</style></head><body>
<h1>Basemap QC Report</h1>
<p><b>Project:</b> {html.escape(qc.project_name)}<br>
<b>Created:</b> {qc.created}<br>
<b>Boundary area:</b> {qc.boundary_area_sqft:,.0f} sq ft
({qc.boundary_area_sqft/43560:,.2f} acres)<br>
<b>Working CRS:</b> {html.escape(qc.working_crs)}<br>
<b>Source provider:</b> {html.escape(qc.source_provider)}</p>
<h2>Feature statistics</h2><table>{rows}</table>
<h2>Warnings</h2><ul>{warns}</ul>
<h2>Attribution</h2><p>{html.escape(qc.attribution)}</p>
<div class="disc"><b>Disclaimer.</b> {html.escape(DISCLAIMER)}</div>
</body></html>"""


def write_reports(qc: QcData, reports_dir: Path, source_meta: dict,
                  projection_meta: dict) -> None:
    reports_dir.mkdir(parents=True, exist_ok=True)
    (reports_dir / "QC_Report.html").write_text(render_html(qc), encoding="utf-8")

    src_lines = [f"Source provider : {qc.source_provider}",
                 f"Retrieved (UTC) : {qc.created}",
                 f"Attribution     : {qc.attribution}"]
    for k, v in source_meta.items():
        src_lines.append(f"{k:<15} : {v}")
    src_lines.append("")
    src_lines.append("DISCLAIMER: " + DISCLAIMER)
    (reports_dir / "Source_Report.txt").write_text("\n".join(src_lines), encoding="utf-8")

    proj_lines = [f"{k:<22} : {v}" for k, v in projection_meta.items()]
    (reports_dir / "Projection_Report.txt").write_text(
        "\n".join(proj_lines), encoding="utf-8")
