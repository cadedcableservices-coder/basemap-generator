"""Export layers to a DXF drawing openable directly in AutoCAD.

* Lines/edges/waterways  -> LWPOLYLINE (lightweight, 2D)
* Buildings / water polys -> closed LWPOLYLINE
* Labels                  -> TEXT with rotation following road direction
* All geometry at elevation Z=0; coordinates are in the working projected CRS.
No images, hatching, or 3D. Layer names + ACI colors come from cad_layers.yaml.
"""
from __future__ import annotations
from pathlib import Path

import ezdxf
from shapely.geometry import LineString, Polygon, MultiPolygon, Point

from ..models.features import FeatureCollection
from .layers import grouped_layers
from ..core.logging import get_logger

log = get_logger(__name__)


def _add_polyline(msp, coords, layer, closed=False):
    pts = [(float(x), float(y)) for x, y in coords]
    msp.add_lwpolyline(pts, dxfattribs={"layer": layer},
                       close=closed)


def _add_polygon(msp, poly: Polygon, layer):
    _add_polyline(msp, list(poly.exterior.coords), layer, closed=True)
    for ring in poly.interiors:
        _add_polyline(msp, list(ring.coords), layer, closed=True)


def export_dxf(fc: FeatureCollection, out_path: str | Path, cfg) -> Path:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc = ezdxf.new(setup=True)
    # DXF units: 2 = feet-ish? INSUNITS 2 == feet only if imperial. Use 2 (feet)
    is_feet = "foot" in str(fc.meta.get("crs_unit", "")).lower()
    doc.header["$INSUNITS"] = 2 if is_feet else 6   # 2=ft, 6=metre
    msp = doc.modelspace()

    # pre-create all layers so empty ones still exist
    for key, spec in cfg.cad_layers["layers"].items():
        doc.layers.add(name=spec["name"], color=int(spec.get("aci", 7)))

    text_h = float(cfg.cad_layers.get("text_height_ft", 4.0))
    if not is_feet:
        text_h *= 0.3048

    groups = grouped_layers(fc)
    counts: dict[str, int] = {}
    for key, feats in groups.items():
        layer = cfg.layer_name(key)
        for f in feats:
            g = f.geometry
            if key in ("road_label", "state_route_label") and isinstance(g, Point):
                txt = f.get("label_text", "")
                ang = float(f.get("angle", 0) or 0)
                mt = msp.add_text(txt, dxfattribs={
                    "layer": layer, "height": text_h, "rotation": ang})
                mt.set_placement((float(g.x), float(g.y)))
            elif isinstance(g, LineString):
                _add_polyline(msp, list(g.coords), layer, closed=False)
            elif isinstance(g, Polygon):
                _add_polygon(msp, g, layer)
            elif isinstance(g, MultiPolygon):
                for p in g.geoms:
                    _add_polygon(msp, p, layer)
            else:
                continue
            counts[layer] = counts.get(layer, 0) + 1
    doc.saveas(out_path)
    log.info("DXF: %s entities across %d layers -> %s",
             sum(counts.values()), len(counts), out_path.name)
    return out_path
