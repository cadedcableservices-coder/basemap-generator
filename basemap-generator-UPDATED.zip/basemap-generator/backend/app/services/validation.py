"""Geometry validation + light repair (spec section 8 steps 8-11)."""
from __future__ import annotations
from dataclasses import dataclass

from shapely.validation import make_valid
from shapely.geometry.base import BaseGeometry

from ..models.features import FeatureCollection
from ..core.logging import get_logger

log = get_logger(__name__)


@dataclass
class ValidationStats:
    invalid_found: int = 0
    repaired: int = 0
    empty_removed: int = 0


def validate_and_repair(fc: FeatureCollection) -> ValidationStats:
    stats = ValidationStats()
    keep = []
    for f in fc.features:
        g: BaseGeometry = f.geometry
        if g is None or g.is_empty:
            stats.empty_removed += 1
            continue
        if not g.is_valid:
            stats.invalid_found += 1
            try:
                repaired = make_valid(g)
                if repaired and not repaired.is_empty:
                    f.geometry = repaired
                    stats.repaired += 1
                    f.set("notes", (f.get("notes", "") + "; geometry repaired").strip("; "))
            except Exception as exc:
                log.warning("repair failed for %s: %s", f.feature_id, exc)
        keep.append(f)
    fc.features = keep
    return stats
