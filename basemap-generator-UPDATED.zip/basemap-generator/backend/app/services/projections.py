"""Coordinate reference system selection + reprojection.

CRITICAL (spec section 7): all distance work (the 18/20 ft offsets) must happen
in a projected CRS whose units are feet or metres -- never in lat/lon degrees.

This module:
* recommends a working CRS from the project centroid,
* reprojects features between CRSs,
* reports the CRS linear unit and a feet->unit multiplier so downstream code
  can express the 18/20 ft rules in the CRS's native units,
* raises visible warnings for unsuitable situations.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

from pyproj import CRS, Transformer
from shapely.geometry.base import BaseGeometry
from shapely.ops import transform as shp_transform

from ..models.features import Feature, FeatureCollection
from ..core.logging import get_logger

log = get_logger(__name__)

WGS84 = "EPSG:4326"
US_FOOT_M = 1200.0 / 3937.0     # US survey foot in metres
INTL_FOOT_M = 0.3048

# Rough PA State Plane north/south split. PA zones are defined by county, so this
# latitude line is an APPROXIMATION used only for the "auto" recommendation; the
# user can always override in the CRS selector.
PA_NS_SPLIT_LAT = 40.88
PA_BBOX = (-80.6, 39.6, -74.6, 42.4)   # (w,s,e,n) approx state extent


@dataclass
class CrsInfo:
    epsg: int | None
    crs: CRS
    unit_name: str            # 'US survey foot' | 'metre' | ...
    feet_per_unit: float      # multiply a value-in-feet by this -> value in CRS units
    warnings: list[str]

    @property
    def is_feet(self) -> bool:
        return "foot" in self.unit_name.lower() or "feet" in self.unit_name.lower()


def _linear_unit(crs: CRS) -> tuple[str, float]:
    """Return (unit_name, metres_per_unit) for a projected CRS."""
    try:
        axis = crs.axis_info[0]
        name = (axis.unit_name or "").lower()
        conv = float(axis.unit_conversion_factor or 1.0)  # metres per unit
        return name or "unknown", conv
    except Exception:
        return "unknown", 1.0


def feet_to_units(feet: float, info: CrsInfo) -> float:
    """Convert a distance in feet to the working CRS's native units."""
    return feet * info.feet_per_unit


def recommend_crs(centroid_lonlat: tuple[float, float],
                  bbox_wgs: tuple[float, float, float, float] | None = None,
                  presets: dict | None = None) -> CrsInfo:
    """Pick a sensible projected CRS for a project centroid."""
    lon, lat = centroid_lonlat
    presets = presets or {}
    warnings: list[str] = []

    in_pa = (PA_BBOX[0] <= lon <= PA_BBOX[2] and PA_BBOX[1] <= lat <= PA_BBOX[3])
    if in_pa:
        epsg = int(presets.get("pa_state_plane_north", 2271)) if lat >= PA_NS_SPLIT_LAT \
            else int(presets.get("pa_state_plane_south", 2272))
        zone = "North" if lat >= PA_NS_SPLIT_LAT else "South"
        warnings.append(
            f"Auto-selected PA State Plane {zone} (EPSG:{epsg}). PA zones are "
            f"county-defined; verify the zone if the project is near the boundary.")
    else:
        # UTM fallback (metres)
        utm_zone = int((lon + 180) // 6) + 1
        epsg = 32600 + utm_zone if lat >= 0 else 32700 + utm_zone
        warnings.append(
            f"Project centroid is outside Pennsylvania; auto-selected UTM zone "
            f"{utm_zone} (EPSG:{epsg}, metres).")

    if bbox_wgs is not None and (bbox_wgs[2] - bbox_wgs[0]) > 1.5:
        warnings.append("Project spans a wide longitude range; a single projected "
                        "CRS may distort distances. Consider splitting the area.")
    return build_crs_info(epsg, extra_warnings=warnings)


def build_crs_info(epsg: int, extra_warnings: list[str] | None = None) -> CrsInfo:
    crs = CRS.from_epsg(epsg)
    warnings = list(extra_warnings or [])
    if crs.is_geographic:
        warnings.append(f"EPSG:{epsg} is geographic (degrees); distance operations "
                        f"would be invalid. Choose a projected CRS.")
    unit_name, metres_per_unit = _linear_unit(crs)
    if "foot" in unit_name or "feet" in unit_name:
        # units are feet -> a value already in feet needs no scaling
        feet_per_unit = 1.0
    elif "metre" in unit_name or "meter" in unit_name:
        feet_per_unit = INTL_FOOT_M          # feet -> metres
    else:
        feet_per_unit = 1.0
        warnings.append(f"Working CRS unit '{unit_name}' is not feet or metres; "
                        f"offset distances may be wrong.")
    return CrsInfo(epsg=epsg, crs=crs, unit_name=unit_name,
                   feet_per_unit=feet_per_unit, warnings=warnings)


def make_transformer(src: str | CRS, dst: str | CRS) -> Transformer:
    return Transformer.from_crs(CRS.from_user_input(src),
                                CRS.from_user_input(dst), always_xy=True)


def reproject_geometry(geom: BaseGeometry, transformer: Transformer) -> BaseGeometry:
    return shp_transform(lambda x, y, z=None: transformer.transform(x, y), geom)


def reproject_features(features: Iterable[Feature], src: str | CRS,
                       dst: str | CRS) -> None:
    """Reproject a set of features IN PLACE."""
    tr = make_transformer(src, dst)
    for f in features:
        f.geometry = reproject_geometry(f.geometry, tr)


def reproject_collection(fc: FeatureCollection, dst_info: CrsInfo,
                         src: str = WGS84) -> None:
    reproject_features(fc.features, src, dst_info.crs)
    fc.meta["crs_epsg"] = dst_info.epsg
    fc.meta["crs_unit"] = dst_info.unit_name
