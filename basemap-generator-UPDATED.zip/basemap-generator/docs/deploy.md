# Hosting the app (so people open a link instead of installing)

The app needs a small always-on server (it runs Python). Two routes:

## Route A — Render.com (public link, easiest)
All dependencies ship as prebuilt wheels, so no Docker or GDAL setup is needed.

1. Put this project in a **GitHub repo** (public or private).
2. Create a free account at https://render.com and click **New + → Blueprint**.
3. Connect the GitHub repo. Render reads `render.yaml` and configures everything:
   - build: `pip install -r backend/requirements.txt`
   - start: `uvicorn backend.app.main:app --host 0.0.0.0 --port $PORT`
4. Click **Apply**. In a few minutes you get a URL like
   `https://fiber-basemap-generator.onrender.com` — share it with anyone.

Notes: the free plan sleeps after ~15 min idle (first hit takes ~30 s to wake).
Only public OpenStreetMap data flows through it — nothing internal is exposed.
Works the same on Railway/Fly.io (a `Procfile` is included).

## Route B — Internal company server (best for company use)
Give IT the repo and this one-liner (Docker is included):
```bash
docker compose up -d --build      # serves on port 8000 of that machine
```
Then everyone opens `http://<that-server-name-or-ip>:8000`. Nothing leaves the
network. To run without Docker on a server that has Python 3.10+:
```bash
pip install -r backend/requirements.txt
HOST=0.0.0.0 PORT=8000 python run.py
```

## Either way
Once live, the site behaves exactly like the local version: draw an area,
Generate, review, Export. The same OpenStreetMap access note applies — the
server needs outbound internet to `overpass-api.de` (unless you also host a
private data source, see docs/data_sources.md).
