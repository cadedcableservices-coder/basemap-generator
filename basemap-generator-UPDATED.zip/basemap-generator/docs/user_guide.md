# User Guide — Web App

The app runs on your own computer. Nothing is uploaded to the cloud; it fetches
map data directly from OpenStreetMap and writes files locally.

## Start it
- **Windows:** double-click `scripts\Start Basemap Generator.bat`. The first run
  installs everything (a few minutes); after that it starts in seconds and opens
  your browser to `http://127.0.0.1:8000`.
- **Any OS:** `pip install -r backend/requirements.txt` then `python run.py`.

> You need an internet connection: the map tiles and live road/water/building
> data come from OpenStreetMap. For a quick offline try-out, tick **"Use bundled
> sample data"** in step 3.

## Make a basemap (7 steps in the left panel)
1. **Project** — give it a name.
2. **Find location** — type an address, town, township, county, or `lat, lng`
   and click *Search & zoom*.
3. **Draw project boundary** — use the ▭ square or polygon tool at the top-right
   of the map to draw your area. Draw again to replace it.
4. **Settings** — road width rule (default: 18/20 ft *total* width → 9/10 ft each
   side), building style, coordinate system (Auto picks PA State Plane), and which
   water features to include.
5. **Generate Basemap** — fetches and builds roads, edges, labels, water, and
   buildings, and draws them on the map. A summary and any warnings appear.
6. **Review roads** — a table lists every road with a status dot
   (green reviewed · yellow needs review · red unknown · gray excluded). You can
   change a road's **class**, toggle it **on/off**, mark it **reviewed (✓)**, or
   **delete (✕)**. Changing a class instantly rebuilds that road's edge lines.
   Click a road name (or the map) to highlight it.
7. **Export** — click *Export CAD package* and download the ZIP (DXF + GeoPackage
   + Shapefiles + QC report). See `docs/cad_import.md` for AutoCAD steps.

## Command-line (optional)
The original CLI still works for batch/offline use:
```
python -m backend.app.cli --project "Area1" --bbox -77.276 41.195 -77.264 41.207
```
