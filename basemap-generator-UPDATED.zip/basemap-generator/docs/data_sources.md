# Data Sources, Caching & Licensing

## Primary source — OpenStreetMap via Overpass
The `osm_overpass` provider issues one Overpass query per project area for roads,
waterways, water bodies, buildings, and road route-relations (`out geom`).

### API safety (config → `overpass:`)
- **Caching:** every response is cached on disk keyed by the exact query, so a
  re-run of the same area does not re-hit Overpass.
- **Retry/backoff:** up to `max_retries` attempts with exponential backoff,
  rotating across `endpoints`.
- **Area limit:** `max_area_sqkm` guards against oversized requests.
- **Offline:** `--overpass-json <file>` feeds a saved response (used by the
  demo and the whole test suite) so nothing depends on the internet.

### For long-term company use
- Download a regional OSM extract (e.g. Geofabrik Pennsylvania).
- Run a **private Overpass instance** and point `endpoints` at it.
- Load extracts into **PostGIS** and add a `postgis` provider.
- Refresh source data on a schedule; the QC report records retrieval date.

## Adding more providers
Implement `BaseProvider` (see `providers/base.py`): `search_location`,
`fetch_roads`, `fetch_waterways`, `fetch_waterbodies`, `fetch_buildings`,
`fetch_route_information`, `normalize_attributes`. Return **WGS84** geometry with
canonical attribute names. Planned: USGS NHD hydrography, PA/county ArcGIS REST,
uploaded Shapefile/GeoJSON/KML, existing company GIS layers.

## Licensing / attribution
OpenStreetMap data is **© OpenStreetMap contributors, ODbL 1.0**. Every export
carries `ATTRIBUTION.txt` and an attribution line in the QC report. Source IDs
(`source`, `source_id`) are preserved on every feature and never stripped. Do not
use copyrighted consumer map screenshots as a geometry source.
