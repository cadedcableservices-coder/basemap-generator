# Architecture & Design — Fiber Basemap Generator

## 1. Spec review — conflicts, ambiguities, decisions

The specification is internally consistent and buildable. A handful of points
needed a decision; each is resolved as follows and is configurable.

| # | Issue in spec | Resolution in this build |
|---|---------------|--------------------------|
| 1 | **"Trace one side and offset 18/20 ft"** is ambiguous — is 18/20 the *total width* or the *centerline-to-edge* distance? | Both are implemented. `width_interpretation: total_width` is the **default** (edge = 9/10 ft from centerline); `edge_offset` gives the full 18/20 ft. Unit-tested both ways. |
| 2 | **Single-edge mode (Mode B)** is a UI-driven manual action. | The offset math (`generate_opposite_edge`) is implemented and unit-tested now; the interactive edge-picking UI lands in Phase 3 as scheduled. |
| 3 | **PA State Plane North vs South** split. Real PA zones are defined by **county**, not latitude. | Auto-recommend uses an approximate latitude line and emits a **warning** telling the user to verify near the boundary; the CRS selector lets them override. A future county-polygon lookup can replace the heuristic without touching callers. |
| 4 | **DWG export.** | Out of scope for the open-source MVP, exactly as the spec says. We emit DXF (opens directly in AutoCAD) + a documented DWG path in `docs/cad_import.md`. |
| 5 | **Overpass area limits vs "generate a large area".** | `overpass.max_area_sqkm` gates requests; the pipeline warns before large fetches. |
| 6 | **`track` roads.** | Excluded by default (`include_tracks: false`); when excluded they are **retained but flagged**, never silently dropped. |
| 7 | **Intersection cleanup.** | MVP uses Option 1 (leave edges as generated for manual cleanup). Offsets use a mitre join to keep linework connected; Option 2 (trim/extend) is a Phase 3 item. |

No requirement was dropped. Items beyond Phase 1 (interactive map, editing, auth,
PostGIS) are scaffolded but intentionally not implemented yet, per the spec's
"do not begin Phase 2 until Phase 1 exports a usable basemap" instruction.

## 2. Architecture plan

A **provider → normalize → project → classify → geometry → validate → export**
pipeline. Each stage is a small, independently testable module with type hints
and logging. Providers are swappable behind `BaseProvider`; exporters and the
geometry engine never know which source produced a feature.

Core principles:
- **One flat feature model** (`Feature` = geometry + attributes + kind) shared by
  every stage, so providers, geometry services and exporters speak one language.
- **Providers return WGS84 only.** All distance math happens *after* reprojection
  to a projected CRS whose units are feet/metres — never in degrees.
- **Config over code.** Classification rules, CAD layer names/colors, widths, CRS
  presets and API safety live in `config/*.yaml`; a copy ships in every export so
  a project regenerates deterministically.
- **Nothing is invented.** Unknown/failed features are flagged for human review.

## 3. Data-flow diagram

```mermaid
flowchart TD
    A[Project boundary<br/>bbox or GeoJSON, WGS84] --> B{Provider<br/>BaseProvider}
    B -->|OSM/Overpass<br/>live or cached JSON| C[Raw features WGS84<br/>roads / waterways / waterbodies / buildings]
    B -.future.-> B2[USGS NHD · County ArcGIS · Uploaded SHP/GeoJSON/KML]
    C --> D[normalize_attributes<br/>canonical fields]
    D --> E[Select working CRS<br/>PA State Plane / UTM / custom EPSG]
    E --> F[Reproject to projected CRS<br/>feet or metres]
    F --> G[Classify roads<br/>side / main / state route + width rule]
    G --> H[Merge contiguous + clip to boundary+buffer]
    H --> I[Road offset engine<br/>Mode A centerline / Mode B single edge]
    H --> J[Water: streams·rivers·bodies filters]
    H --> K[Buildings: footprint / rotated rect / bbox]
    H --> L[Labels: name / ref / combined + angle]
    I --> M[Validate + repair geometry]
    J --> M
    K --> M
    L --> M
    M --> N[[Export]]
    N --> O[DXF · layered, Z=0]
    N --> P[GeoPackage · all layers]
    N --> Q[Shapefiles + .prj]
    N --> R[QC report + Source/Projection reports]
    N --> S[project_settings.json + ATTRIBUTION.txt]
    O & P & Q & R & S --> T[(Project_Basemap.zip)]
```

## 4. Repository tree

```
basemap-generator/
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── cli.py                 # Phase 1 command-line entry point
│       ├── pipeline.py            # orchestrator (boundary -> export)
│       ├── core/                  # config loader, logging
│       ├── models/features.py     # Feature / FeatureCollection
│       ├── providers/             # base.py, osm_overpass.py (+ future sources)
│       ├── services/              # projections, classification, road_offset,
│       │                          #   waterways, buildings, labels, validation,
│       │                          #   layers, export_dxf/shapefile/geopackage,
│       │                          #   qc_report, geocoding
│       ├── api/                   # (Phase 2 FastAPI routes)
│       ├── schemas/               # (Phase 2 pydantic models)
│       └── tests/                 # unit + integration tests (offline)
├── frontend/                      # (Phase 2 React + MapLibre — scaffold only)
├── config/                        # road_classification / cad_layers / default_settings
├── sample_data/                   # bundled offline PA Overpass sample
├── scripts/                       # Windows .bat/.ps1 + linux .sh launchers
├── docs/                          # architecture, installation, user_guide, data_sources, cad_import
├── Dockerfile · docker-compose.yml
├── pyproject.toml · README.md · LICENSE
```

## 5. Dependencies & licenses

| Package | Purpose | License |
|---------|---------|---------|
| shapely | geometry (offset, clip, validate) | BSD-3 |
| pyproj | CRS + reprojection | MIT |
| geopandas | GPKG/SHP IO | BSD-3 |
| pyogrio | fast OGR IO backend | MIT |
| ezdxf | DXF writing | MIT |
| pyyaml | config | MIT |
| requests | Overpass/Nominatim HTTP | Apache-2.0 |
| fastapi / uvicorn / pydantic | Phase 2 web API | MIT / BSD / MIT |
| pytest | tests | MIT |
| **OpenStreetMap data** | source geometry | **ODbL 1.0** (attribution required) |

All code dependencies are permissive (MIT/BSD/Apache). The **data** is ODbL —
attribution is written into every export (`ATTRIBUTION.txt`, QC report).

## 6. How DXF export works

`services/export_dxf.py` uses **ezdxf**:
1. `ezdxf.new(setup=True)` creates an R2018 document with standard resources.
2. `$INSUNITS` is set to **2 (feet)** when the working CRS unit is feet, else
   **6 (metres)**, so AutoCAD interprets coordinates at true scale.
3. Every CAD layer from `cad_layers.yaml` is pre-created (with its ACI color) so
   empty layers still exist in the drawing.
4. Features are written per layer:
   - lines/edges/waterways → `LWPOLYLINE` (open),
   - buildings & water polygons → `LWPOLYLINE` (closed), interior rings added,
   - labels → `TEXT` with `rotation` = the road-direction angle.
5. All geometry is 2D at **Z=0**; no images, hatching, or 3D.
6. `doc.saveas(...)` writes the DXF, which opens directly in AutoCAD and can be
   saved as DWG there (see `docs/cad_import.md`).

Coordinates are already in the projected CRS (feet), so 1 drawing unit = 1 foot.

## 7. How road offsets are generated & how failures are handled

`services/road_offset.py`:
- Each included centerline gets a **width in feet** from its class
  (`side_road`→18, `main_road`/`state_route`→20; configurable).
- The centerline-to-edge distance depends on `width_interpretation`:
  `total_width` → width/2 (9/10 ft); `edge_offset` → full width.
- That feet value is converted to **CRS units** (`feet_to_units`) so metre-based
  CRSs work too.
- **Shapely `offset_curve`** produces each edge: positive = left of line
  direction, negative = right (mitre join keeps corners connected).
- Results are cleaned: a `MultiLineString` collapses to its longest part; empty
  or zero-length results return `None`.
- **Failure handling:** any centerline that yields fewer than 2 edges is
  counted (`OffsetStats.failed`), left in place with a `"offset produced N/2
  edges - review"` note, and `reviewed=False`. It is never dropped or faked.
- **Mode B** (`generate_opposite_edge`) offsets a user-supplied edge by the full
  18/20 ft to the chosen side.

These are drafting basemap lines, **not** engineering curb lines — stated plainly
in the QC disclaimer.

## 8. How the projected CRS is selected

`services/projections.py`:
- `crs_mode: auto` → `recommend_crs(centroid)`:
  - inside PA bbox → PA State Plane **North (2271)** or **South (2272)** by an
    approximate latitude split, **with a warning** to verify (zones are
    county-defined);
  - outside PA → the correct **UTM zone** (metres).
- `crs_mode: epsg` → uses `crs_epsg` verbatim.
- `build_crs_info` inspects the CRS's linear unit and computes `feet_per_unit`
  (1.0 for foot CRSs, 0.3048 for metre CRSs) so all 18/20 ft rules are expressed
  in native units.
- **Warnings** are raised for: geographic (degree) CRS, non-foot/metre units, and
  projects spanning a wide longitude range. Exports always include a `.prj` and a
  `Projection_Report.txt`.

## 9. Web application (Phase 2–3)

A **FastAPI** backend serves both the JSON API and a single self-contained web
page (`frontend/index.html`, Leaflet + Leaflet-Geoman, no build step). State for
active projects lives in an in-memory store; exports and settings are written to
disk. Multi-user auth + PostGIS is Phase 4 (not built).

### Endpoints
```
GET    /                                  the web UI
GET    /api/health
POST   /api/geocode                       {query} -> Nominatim results
POST   /api/project                       {name, settings} -> {project_id}
GET    /api/project/{id}
POST   /api/project/{id}/boundary         {bbox | geojson}
PUT    /api/project/{id}/settings         {settings}  (re-assembles if generated)
POST   /api/project/{id}/fetch-features   {use_sample} -> {summary, geojson}
GET    /api/project/{id}/features         -> WGS84 GeoJSON
PATCH  /api/project/{id}/features/{fid}   {attributes?, geometry?}  (regenerates edges)
DELETE /api/project/{id}/features/{fid}
POST   /api/project/{id}/add-road         {geometry, attributes}
POST   /api/project/{id}/export           -> {export_id, download_url}
GET    /api/project/{id}/export/{eid}     -> ZIP download
```

Geometry crosses the wire as **WGS84 GeoJSON** for the map; the backend keeps the
working copy in the projected CRS and reprojects on the fly. Editing a road's
class/width/geometry rebuilds just that road's two edge lines.

### Phase status
- **Phase 1 (CLI):** complete, tested.
- **Phase 2 (web app: map, search, boundary draw, generate, review, export):** complete, tested.
- **Phase 3 (editing: reclassify, include/exclude, width, delete, geometry edit + single-edge offset math):** implemented via the API/UI and the offset engine; advanced intersection trimming is future.
- **Phase 4 (auth, shared PostGIS, audit trail, templates):** not started by design.
