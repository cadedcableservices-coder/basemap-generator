# Installation (Windows)

## Requirements
- Windows 10/11
- Python 3.10+ (from python.org — check **"Add python.exe to PATH"** during install)
- Internet access (for OpenStreetMap map tiles and data)

## Install & run (one-click)
1. Unzip the project to e.g. `C:\Tools\basemap-generator`.
2. Open the `scripts` folder.
3. Double-click **`Start Basemap Generator.bat`**.
   - First run creates a virtual environment and installs dependencies (minutes).
   - Then it starts the local server and opens your browser to
     `http://127.0.0.1:8000`.
4. To stop, close the black console window.

If PowerShell blocks the installer, run once:
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.

## Manual / developer
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
python run.py            REM web app on http://127.0.0.1:8000
pytest                   REM 39 tests, all offline
```

## Docker
```bash
docker compose up --build     # app on http://localhost:8000
```

## Geospatial stack
`shapely`, `pyproj`, `geopandas`, `pyogrio`, `ezdxf` ship prebuilt wheels
(GDAL bundled in `pyogrio`) — **no separate GDAL install needed** on Windows.
