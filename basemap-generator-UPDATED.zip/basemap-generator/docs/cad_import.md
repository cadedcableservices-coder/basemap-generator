# Importing into AutoCAD

## DXF (recommended, simplest)
1. In AutoCAD: **Open** `CAD\<Project>_Basemap.dxf` (or `DXFIN`).
2. Layers arrive pre-separated: `BASE_ROAD_EDGE`, `BASE_ROAD_CENTERLINE`,
   `BASE_ROAD_LABEL`, `BASE_STATE_ROUTE_LABEL`, `BASE_STREAM`, `BASE_RIVER`,
   `BASE_WATER_BODY`, `BASE_BUILDING`, `BASE_PROJECT_BOUNDARY`.
3. Units are feet (`$INSUNITS=2`); 1 drawing unit = 1 foot. Coordinates are in
   the project's State Plane / UTM CRS, so the drawing is georeferenced.
4. To save as DWG: **Save As → AutoCAD Drawing (*.dwg)**.

## Shapefiles (AutoCAD Map 3D / Civil 3D)
Use **MAPIMPORT** and select the `.shp` files under `GIS\Shapefiles\...`. Each
carries a `.prj`, so Map 3D reprojects correctly. Attribute fields (name, ref,
class, width) come in as object data.

## GeoPackage
`GIS\<Project>_Basemap.gpkg` holds every layer with full attributes and CRS —
ideal for QGIS review before/after CAD import.

## Optional DXF→DWG automation
Not required for the MVP. Options for later: AutoCAD `DWGCONVERT`/scripted
`accoreconsole.exe`, ODA File Converter (Teigha), or a Civil 3D batch. Keep DXF
as the reliable open-source deliverable.
