"""Start the Basemap Generator web app and open the browser.

    python run.py            # http://127.0.0.1:8000
"""
from __future__ import annotations
import uvicorn
from backend.app.main import app, open_browser

import os

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    # Only auto-open a browser when running locally, not when hosted.
    if host in ("127.0.0.1", "localhost"):
        open_browser(f"http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")
