@echo off
REM Double-click to launch the Basemap Generator web app. Browser opens automatically.
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo First run: installing. This can take a few minutes...
  powershell -ExecutionPolicy Bypass -File "scripts\install_windows.ps1"
)
call .venv\Scripts\activate.bat
echo Starting server at http://127.0.0.1:8000  (close this window to stop)
python run.py
pause
