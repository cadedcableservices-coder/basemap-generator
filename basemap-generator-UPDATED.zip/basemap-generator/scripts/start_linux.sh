#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -q -r backend/requirements.txt
echo "Starting Basemap Generator at http://127.0.0.1:8000 (Ctrl+C to stop)"
python run.py
