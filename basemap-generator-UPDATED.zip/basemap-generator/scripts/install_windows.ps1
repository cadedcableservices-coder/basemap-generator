# One-time setup on Windows. Requires Python 3.10+ from python.org (check "Add to PATH").
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
Write-Host "Creating virtual environment..."
python -m venv .venv
.\.venv\Scripts\Activate.ps1
Write-Host "Installing dependencies (this can take a few minutes)..."
python -m pip install --upgrade pip
python -m pip install -r backend\requirements.txt
Write-Host "Install complete. Double-click 'Start Basemap Generator.bat' to run the demo."
