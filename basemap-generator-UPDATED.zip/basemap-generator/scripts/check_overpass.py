"""Diagnostic: test each Overpass endpoint from THIS machine and report results.

Run:  python scripts\check_overpass.py     (Windows)
      python3 scripts/check_overpass.py     (mac/Linux)
Paste the output back to whoever is helping you set this up.
"""
import sys, time, urllib.request, urllib.error

ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
    "https://overpass.osm.ch/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
]
# tiny query: one node in a very small box near Williamsport, PA
QUERY = "[out:json][timeout:25];node(41.24,-77.05,41.25,-77.04);out 1;"
HEADERS = {
    "User-Agent": "basemap-generator/0.2 (diagnostic; caded@cable-services.com)",
    "Accept": "application/json,*/*",
}

def test(url):
    data = ("data=" + urllib.parse.quote(QUERY)).encode()
    req = urllib.request.Request(url, data=data, headers=HEADERS, method="POST")
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            body = r.read(200).decode("utf-8", "replace")
            return f"OK  {r.status}  ({time.time()-t0:.1f}s)  {body[:60]!r}"
    except urllib.error.HTTPError as e:
        return f"HTTP {e.code} {e.reason}  ({time.time()-t0:.1f}s)"
    except Exception as e:
        return f"FAIL  {type(e).__name__}: {e}"

if __name__ == "__main__":
    import urllib.parse
    print("Testing Overpass endpoints from this machine...\n")
    for url in ENDPOINTS:
        print(f"{url}\n   -> {test(url)}\n")
    print("Done. 'OK 200' on any line means data access works from here.")
