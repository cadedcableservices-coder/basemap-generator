@echo off
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" ( powershell -ExecutionPolicy Bypass -File "scripts\install_windows.ps1" )
call .venv\Scripts\activate.bat
python -m backend.app.cli --project "PineCreek_Demo" --bbox -77.276 41.195 -77.264 41.207 --overpass-json sample_data\pa_rural_pine_creek.overpass.json --out output
echo. & echo Done. See the "output" folder. & pause
